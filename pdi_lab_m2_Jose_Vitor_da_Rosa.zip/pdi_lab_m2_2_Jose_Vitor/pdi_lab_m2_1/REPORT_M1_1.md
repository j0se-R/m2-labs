# Mini relatorio — Laboratorio M1.1

## Identificacao

- Estudante: José Vitor da Rosa
- Matricula: 8191042
- Laboratorio: M1.1 — Representacao, canais e niveis de cinza
- Linguagem: Python

## 1. Objetivo

O objetivo deste laboratorio foi implementar operacoes fundamentais de representacao de imagens digitais por meio de acesso direto aos pixels, trabalhando com dimensoes, canais, intensidade e resolucao radiometrica. Foram implementadas inspeção, copia, separacao de canais, conversao para niveis de cinza e quantizacao.

## 2. Operacoes implementadas

- **Inspecao:** percorri os pixels manualmente para obter largura, altura, numero de canais, tipo, quantidade de pixels e estatisticas de intensidade. Em imagens coloridas, as estatisticas foram calculadas separadamente para B, G e R.
- **Copia:** criei uma nova matriz e copiei cada pixel individualmente.
- **Canais:** considerei a ordem BGR usada pelo OpenCV e preservei somente o canal solicitado, zerando os demais.
- **Niveis de cinza:** implementei a media simples `(R+G+B)/3` e a media ponderada `0,299R + 0,587G + 0,114B`, com arredondamento para `uint8`.
- **Quantizacao:** usei quantizacao uniforme com representantes igualmente espacados no intervalo `[0,255]`, para 2, 4, 8 ou 16 niveis.

## 3. Testes realizados

| Teste | Entrada | Operacao | Parametros | Resultado esperado ou criterio de verificacao |
|---|---|---|---|---|
| Copia exata | imagem sintetica 2x2 | copy | — | Saida numericamente identica a entrada e armazenada em nova matriz. |
| Ordem dos canais | `m1_color_2x2.png` / caso sintetico | channel_b/g/r | canal correspondente | Somente o canal solicitado permanece; os demais sao zero. |
| Cinza por media | caso sintetico RGB com vermelho, verde, azul e branco | grayscale_average | — | Resultados previstos manualmente: 85, 85, 85 e 255. |
| Cinza ponderado | mesmo caso sintetico | grayscale_weighted | — | Resultados previstos: aproximadamente 76, 150, 29 e 255. |
| Quantizacao 16 | `m1_gray_ramp_256.png` | quantize | `levels=16` | A saida possui 16 niveis distintos. |
| Quantizacao 8 | `m1_gray_ramp_256.png` | quantize | `levels=8` | A saida possui 8 niveis distintos. |
| Quantizacao 4 | `m1_gray_ramp_256.png` | quantize | `levels=4` | A saida possui 4 niveis distintos. |
| Quantizacao 2 | `m1_gray_ramp_256.png` | quantize | `levels=2` | A saida possui 2 niveis distintos. |
| Limites da quantizacao | `m1_gray_ramp_256.png` | quantize | 2/4/8/16 | Todos os valores permanecem entre 0 e 255. |
| Inspecao | `m1_color_2x2.png` e imagens em cinza | inspect | — | Dimensoes, canais, tipo e estatisticas devem ser coerentes com a imagem. |

Tambem foram executados testes automatizados para os casos sinteticos, incluindo copia exata, ordem BGR, duas formulas de cinza, quantidade de niveis e entradas incompatíveis.

## 4. Resultados

| Operacao | Entrada | Parametros | Arquivo de saida | Observacao |
|---|---|---|---|---|
| Copia | `images/input/m1_color_scene_256.png` | — | `images/output/m11_copy.png` | Copia pixel a pixel. |
| Canal azul | `images/input/m1_color_scene_256.png` | — | `images/output/m11_channel_b.png` | Mantem somente B. |
| Canal verde | `images/input/m1_color_scene_256.png` | — | `images/output/m11_channel_g.png` | Mantem somente G. |
| Canal vermelho | `images/input/m1_color_scene_256.png` | — | `images/output/m11_channel_r.png` | Mantem somente R. |
| Cinza simples | `images/input/m1_color_scene_256.png` | — | `images/output/m11_gray_average.png` | Media simples. |
| Cinza ponderado | `images/input/m1_color_scene_256.png` | — | `images/output/m11_gray_weighted.png` | Media ponderada. |
| Quantizacao | `images/input/m1_gray_ramp_256.png` | `levels=16` | `images/output/m11_quant_16.png` | 16 niveis. |
| Quantizacao | `images/input/m1_gray_ramp_256.png` | `levels=8` | `images/output/m11_quant_8.png` | 8 niveis. |
| Quantizacao | `images/input/m1_gray_ramp_256.png` | `levels=4` | `images/output/m11_quant_4.png` | 4 niveis. |
| Quantizacao | `images/input/m1_gray_ramp_256.png` | `levels=2` | `images/output/m11_quant_2.png` | 2 niveis. |

## 5. Analise tecnica

### 1. Qual e a diferenca entre resolucao espacial e resolucao radiometrica?

A resolucao espacial esta relacionada a quantidade de pixels utilizada para representar as dimensoes da imagem. Quanto maior a quantidade de pixels, maior a capacidade de representar detalhes espaciais. A resolucao radiometrica esta relacionada a quantidade de niveis de intensidade disponiveis para representar cada pixel. Neste laboratorio, uma imagem `uint8` possui 256 niveis, de 0 a 255.

### 2. Por que a media ponderada produz resultado diferente da media simples?

A media simples atribui o mesmo peso a R, G e B. A media ponderada utiliza pesos diferentes, dando maior contribuicao ao verde, depois ao vermelho e menor ao azul. Isso aproxima a conversao da resposta visual humana e faz com que as duas formulas produzam intensidades diferentes para a maioria das cores.

### 3. O que ocorre visualmente quando a quantidade de niveis e reduzida?

A imagem passa a apresentar menos tons disponiveis. Gradientes suaves ficam mais discretos e podem aparecer regioes com tons constantes ou transicoes abruptas. Com 2 niveis, por exemplo, a imagem se torna essencialmente binaria.

### 4. Em quais regioes da imagem a perda de informacao fica mais evidente?

A perda tende a ficar mais evidente em gradientes, sombras e regioes com pequenas variacoes de intensidade. Nessas areas, varios valores originais passam a ser representados pelo mesmo nivel quantizado. O efeito fica especialmente claro ao comparar as versoes de 16, 8, 4 e 2 niveis da imagem `m1_gray_ramp_256.png`.

### 5. Como o tipo e o numero de canais da imagem interferem na forma de acessar um pixel?

Uma imagem em tons de cinza possui um valor por pixel, enquanto uma imagem colorida BGR possui tres valores por pixel, um para cada canal. Por isso, o acesso a uma imagem colorida precisa considerar tambem o indice do canal. O projeto utiliza a convencao BGR do OpenCV, de modo que os indices 0, 1 e 2 correspondem a azul, verde e vermelho.

## 6. Limitacoes

A implementacao da M1.1 foi direcionada para imagens `uint8` e para imagens coloridas BGR com tres canais nas operacoes que dependem de cor. A quantizacao foi implementada somente para 2, 4, 8 e 16 niveis, conforme o contrato.

As operacoes foram implementadas manualmente com percurso explicito dos pixels. Outras profundidades, formatos multicanais diferentes de BGR e metodos de quantizacao nao fazem parte do escopo desta etapa.

## 7. Referencias

- Roteiro do Laboratorio M1.1 — Processamento de Imagens, 2026-02.
- Documentacao do projeto-base fornecido para a disciplina.
- Documentacao da biblioteca OpenCV utilizada pelo projeto para leitura e escrita das imagens.
