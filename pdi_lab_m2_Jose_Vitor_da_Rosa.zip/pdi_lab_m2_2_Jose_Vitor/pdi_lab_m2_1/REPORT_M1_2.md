# Mini relatorio — Laboratorio M1.2

Identificação
Estudante: José Vitor da Rosa
Matrícula: 8191042
Laboratório: M1.2 — Transformações de intensidade
Linguagem: Python

1. Objetivo

Implementar transformações pontuais de intensidade em imagens em níveis de cinza e analisar como essas operações alteram os valores dos pixels e a distribuição das intensidades.

As operações foram implementadas manualmente, utilizando percurso explícito dos pixels, de forma que cada pixel de saída dependesse somente do pixel correspondente da imagem de entrada.

2. Operações implementadas
Brightness: \(g=f+b\), com saturação no intervalo [0,255].
Contrast: \(g=\alpha(f-128)+128\), com saturação no intervalo [0,255].
Negative: \(g=255-f\).
Threshold: pixels menores que \(T\) recebem 0 e pixels maiores ou iguais a \(T\) recebem 255.
Histogram: contagem manual das 256 possíveis intensidades.

Foram utilizados cálculos em ponto flutuante quando necessário e conversão final para uint8, com arredondamento e saturação.

3. Testes realizados

| Teste                   | Entrada                 | Operação     | Parâmetros     | Resultado esperado ou critério de verificação |
| ----------------------- | ----------------------- | ------------ | -------------- | --------------------------------------------- |
| Brilho positivo         | `m1_gray_scene_256.png` | `brightness` | `b=40`         | Intensidades aumentadas e limitadas a 255     |
| Brilho negativo         | `m1_gray_scene_256.png` | `brightness` | `b=-40`        | Intensidades reduzidas e limitadas a 0        |
| Contraste reduzido      | `m1_gray_scene_256.png` | `contrast`   | `α=0,5`        | Valores aproximados de 128                    |
| Contraste identidade    | `m1_gray_scene_256.png` | `contrast`   | `α=1,0`        | Imagem preservada                             |
| Contraste ampliado      | `m1_gray_scene_256.png` | `contrast`   | `α=1,5`        | Maior separação entre intensidades            |
| Negativo                | `m1_gray_scene_256.png` | `negative`   | —              | Cada valor transformado em `255-f`            |
| Threshold               | `m1_gray_scene_256.png` | `threshold`  | `T=80`         | Somente valores 0 e 255                       |
| Threshold               | `m1_gray_scene_256.png` | `threshold`  | `T=150`        | Somente valores 0 e 255                       |
| Saturação inferior      | imagem sintética        | `brightness` | valor negativo | Valores abaixo de 0 convertidos para 0        |
| Saturação superior      | imagem sintética        | `brightness` | valor positivo | Valores acima de 255 convertidos para 255     |
| Histograma original     | `m1_gray_scene_256.png` | `histogram`  | —              | 256 posições contabilizadas                   |
| Histograma transformado | imagem transformada     | `histogram`  | —              | Distribuição compatível com a transformação   |

A suíte automatizada apresentou 12 testes aprovados.

4. Resultados

| Operação   | Entrada                 | Parâmetros | Arquivo de saída             | Observação                    |
| ---------- | ----------------------- | ---------- | ---------------------------- | ----------------------------- |
| Brightness | `m1_gray_scene_256.png` | `b=40`     | `brightness_plus40.png`      | Imagem mais clara             |
| Brightness | `m1_gray_scene_256.png` | `b=-40`    | `brightness_minus40.png`     | Imagem mais escura            |
| Contrast   | `m1_gray_scene_256.png` | `α=0,5`    | `contrast_05.png`            | Contraste reduzido            |
| Contrast   | `m1_gray_scene_256.png` | `α=1,0`    | `contrast_10.png`            | Imagem preservada             |
| Contrast   | `m1_gray_scene_256.png` | `α=1,5`    | `contrast_15.png`            | Contraste aumentado           |
| Negative   | `m1_gray_scene_256.png` | —          | `negative.png`               | Intensidades invertidas       |
| Threshold  | `m1_gray_scene_256.png` | `T=80`     | `thresh_80.png`              | Limiarização binária          |
| Threshold  | `m1_gray_scene_256.png` | `T=150`    | `thresh_150.png`             | Limiarização com outro corte  |
| Histogram  | `m1_gray_scene_256.png` | —          | `hist_original.csv`          | Histograma da imagem original |
| Histogram  | `brightness_plus40.png` | —          | `hist_brightness_plus40.csv` | Histograma após brilho        |
| Histogram  | `contrast_15.png`       | —          | `hist_contrast_15.csv`       | Histograma após contraste     |


5. Análise técnica

1. Diferença entre brilho e contraste:
O brilho desloca as intensidades para valores maiores ou menores. O contraste altera a distância dos valores em relação ao nível central 128. Portanto, brilho modifica a posição da distribuição, enquanto contraste modifica sua dispersão.

2. Saturação:
A saturação ocorre quando os resultados ficam abaixo de 0 ou acima de 255. No brilho positivo, valores acima de 255 são convertidos para 255. No brilho negativo, valores abaixo de 0 são convertidos para 0. O aumento de contraste também pode produzir saturação nas extremidades. Essa operação provoca perda de informação nessas regiões.

3. Histograma após alteração do brilho:
O aumento do brilho desloca o histograma para a direita, pois os pixels passam a possuir intensidades maiores. A redução do brilho produz o deslocamento contrário, para a esquerda. A saturação pode concentrar pixels nas extremidades.

4. Distribuição após alteração do contraste:
Com \(\alpha=0,5\), os valores se concentram próximos de 128. Com \(\alpha=1,0\), a distribuição permanece igual. Com \(\alpha=1,5\), os valores se afastam de 128, aumentando o contraste e podendo provocar saturação.

5. Informação perdida pela limiarização:
A limiarização elimina as diferenças entre as diversas intensidades dentro de cada classe. Todos os pixels abaixo do limiar tornam-se 0 e todos os pixels acima ou iguais ao limiar tornam-se 255. Dessa forma, informações de intensidade e detalhes intermediários são perdidos.

6. Limitações

A implementação foi direcionada para imagens em níveis de cinza com valores uint8 no intervalo de 0 a 255.

As transformações utilizam saturação para manter os resultados no intervalo válido, o que inevitavelmente provoca perda de informação quando valores ultrapassam os limites.

Os histogramas foram implementados para imagens com 256 níveis de intensidade.

7. Referências
Material e roteiro do Laboratório M1.2 — Transformações de intensidade, Processamento de Imagens 2026-02.
Documentação do Python.
Documentação do NumPy.
Documentação do OpenCV.