import numpy as np
import pytest

from pdi_lab.operations import brightness, contrast, histogram, negative, threshold


def test_brightness_positive_and_negative_with_saturation():
    image = np.array([[0, 10, 250, 255]], dtype=np.uint8)
    np.testing.assert_array_equal(brightness(image, 10), [[10, 20, 255, 255]])
    np.testing.assert_array_equal(brightness(image, -20), [[0, 0, 230, 235]])


def test_contrast_reduced_identity_and_increased():
    image = np.array([[0, 64, 128, 192, 255]], dtype=np.uint8)
    np.testing.assert_array_equal(contrast(image, 1.0), image)
    np.testing.assert_array_equal(contrast(image, 0.5), [[64, 96, 128, 160, 192]])
    np.testing.assert_array_equal(contrast(image, 1.5), [[0, 32, 128, 224, 255]])


def test_negative():
    image = np.array([[0, 50, 128, 255]], dtype=np.uint8)
    np.testing.assert_array_equal(negative(image), [[255, 205, 127, 0]])


def test_two_thresholds():
    image = np.array([[50, 100, 150, 200]], dtype=np.uint8)
    np.testing.assert_array_equal(threshold(image, 100), [[0, 255, 255, 255]])
    np.testing.assert_array_equal(threshold(image, 180), [[0, 0, 0, 255]])


def test_histogram_manual_counts():
    image = np.array([[0, 0, 2], [2, 2, 255]], dtype=np.uint8)
    h = histogram(image)
    assert len(h) == 256
    assert h[0] == 2
    assert h[2] == 3
    assert h[255] == 1
    assert sum(h) == image.size


def test_rejects_color_and_non_uint8_images():
    with pytest.raises(ValueError):
        negative(np.zeros((2, 2, 3), dtype=np.uint8))
    with pytest.raises(ValueError):
        histogram(np.zeros((2, 2), dtype=np.uint16))
