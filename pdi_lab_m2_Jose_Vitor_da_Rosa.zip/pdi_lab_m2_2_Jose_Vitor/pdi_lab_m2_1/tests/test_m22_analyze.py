from pathlib import Path
import csv
import json
import subprocess
import sys

import cv2
import numpy as np
import pytest

from pdi_lab.analyze import analyze_mask, component_rows, validate_binary_mask

ROOT = Path(__file__).resolve().parents[1]

def test_diagonal_pixels_connectivity_4_and_8():
    mask = np.zeros((3, 3), dtype=np.uint8)
    mask[0, 0] = 255
    mask[1, 1] = 255
    assert component_rows(mask, 4, 0)[1]["components_raw"] == 2
    assert component_rows(mask, 8, 0)[1]["components_raw"] == 1

def test_opening_removes_isolated_noise_and_preserves_main_region(tmp_path):
    mask = np.zeros((25, 25), dtype=np.uint8)
    mask[5:20, 5:20] = 255
    mask[1, 1] = 255
    result = analyze_mask(mask, tmp_path / "sample", kernel_size=3, iterations=1, min_area=1)
    final = cv2.imread(str(tmp_path / "sample_final.png"), cv2.IMREAD_GRAYSCALE)
    assert final[1, 1] == 0
    assert final[10, 10] == 255
    assert result["final"]["foreground_pixels"] < result["initial"]["foreground_pixels"]

def test_closing_fills_small_hole(tmp_path):
    mask = np.zeros((25, 25), dtype=np.uint8)
    mask[4:21, 4:21] = 255
    mask[12, 12] = 0
    analyze_mask(mask, tmp_path / "close", sequence="close-open", kernel_size=3, min_area=1)
    final = cv2.imread(str(tmp_path / "close_final.png"), cv2.IMREAD_GRAYSCALE)
    assert final[12, 12] == 255

def test_empty_mask_and_border_touching_object(tmp_path):
    empty = np.zeros((8, 8), dtype=np.uint8)
    result = analyze_mask(empty, tmp_path / "empty")
    assert result["initial"]["components_raw"] == 0
    mask = np.zeros((10, 10), dtype=np.uint8)
    mask[0:4, 0:4] = 255
    rows, stats = component_rows(mask, 8, 0)
    assert stats["components_raw"] == 1
    assert rows[0]["x"] == 0 and rows[0]["y"] == 0

def test_rejects_non_binary_mask():
    with pytest.raises(ValueError, match="somente os valores 0 e 255"):
        validate_binary_mask(np.array([[0, 127]], dtype=np.uint8))

def test_cli_invalid_connectivity_returns_nonzero():
    mask_path = ROOT / "images" / "output" / "m21_favoravel_fixed_mask.png"
    result = subprocess.run([sys.executable, "-m", "pdi_lab", "--operation", "analyze",
        "--input", str(mask_path), "--output", "results/invalid", "--connectivity", "6"],
        cwd=ROOT, capture_output=True, text=True)
    assert result.returncode != 0

def test_analyze_outputs_and_area_sum(tmp_path):
    mask = np.zeros((30, 30), dtype=np.uint8)
    mask[2:8, 2:8] = 255
    mask[15:25, 15:25] = 255
    summary = analyze_mask(mask, tmp_path / "case", min_area=20)
    for suffix, key in [("initial", "initial"), ("final", "final")]:
        with open(tmp_path / f"case_{suffix}.csv", newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        assert sum(int(row["area"]) for row in rows) == summary[key]["foreground_pixels"]
    assert (tmp_path / "case_labels.png").is_file()
    assert json.loads((tmp_path / "case_summary.json").read_text(encoding="utf-8"))["connectivity_selected"] == 8
