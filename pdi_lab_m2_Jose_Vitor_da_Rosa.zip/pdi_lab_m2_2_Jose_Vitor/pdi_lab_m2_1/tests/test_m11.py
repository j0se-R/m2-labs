from pathlib import Path

import cv2
import numpy as np
import pytest

from pdi_lab.operations import (
    channel_image,
    copy_manual,
    grayscale_average,
    grayscale_weighted,
    inspect_image,
    quantize,
)


def test_copy_is_pixel_exact():
    image = np.array([[0, 10], [200, 255]], dtype=np.uint8)
    copied = copy_manual(image)
    np.testing.assert_array_equal(copied, image)
    assert copied is not image


def test_channels_follow_opencv_bgr_order():
    image = np.array([[[255, 0, 0], [0, 255, 0]]], dtype=np.uint8)
    blue = channel_image(image, 0)
    green = channel_image(image, 1)
    red = channel_image(image, 2)
    np.testing.assert_array_equal(blue, [[[255, 0, 0], [0, 0, 0]]])
    np.testing.assert_array_equal(green, [[[0, 0, 0], [0, 255, 0]]])
    np.testing.assert_array_equal(red, [[[0, 0, 0], [0, 0, 0]]])


def test_grayscale_average_and_weighted_manual_case():
    # RGB: red, green, blue, white. OpenCV stores BGR.
    image = np.array(
        [[[0, 0, 255], [0, 255, 0]], [[255, 0, 0], [255, 255, 255]]],
        dtype=np.uint8,
    )
    np.testing.assert_array_equal(grayscale_average(image), [[85, 85], [85, 255]])
    np.testing.assert_array_equal(grayscale_weighted(image), [[76, 150], [29, 255]])


def test_quantize_has_requested_number_of_levels():
    image = np.arange(256, dtype=np.uint8).reshape(16, 16)
    for levels in (2, 4, 8, 16):
        output = quantize(image, levels)
        assert len(np.unique(output)) == levels
        assert int(output.min()) >= 0
        assert int(output.max()) <= 255


def test_inspection_gray_and_color():
    gray = np.array([[0, 10], [20, 30]], dtype=np.uint8)
    info = inspect_image(gray)
    assert info["width"] == "2"
    assert info["height"] == "2"
    assert info["channels"] == "1"
    assert info["min"] == "0"
    assert info["max"] == "30"
    assert info["mean"] == "15.0"

    color = np.array([[[10, 20, 30], [40, 50, 60]]], dtype=np.uint8)
    info = inspect_image(color)
    assert info["channels"] == "3"
    assert info["min_b"] == "10"
    assert info["max_b"] == "40"
    assert info["mean_b"] == "25.0"
    assert info["mean_g"] == "35.0"
    assert info["mean_r"] == "45.0"


def test_m11_rejects_incompatible_inputs():
    with pytest.raises(ValueError):
        channel_image(np.zeros((2, 2), dtype=np.uint8), 0)
    with pytest.raises(ValueError):
        grayscale_average(np.zeros((2, 2), dtype=np.uint8))
    with pytest.raises(ValueError):
        quantize(np.zeros((2, 2, 3), dtype=np.uint8), 4)
