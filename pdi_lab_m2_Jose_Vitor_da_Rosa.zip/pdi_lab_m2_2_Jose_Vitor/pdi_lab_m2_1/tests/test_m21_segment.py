import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

from pdi_lab.segment import segment_image, mask_statistics

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "images" / "input"


def test_fixed_threshold_boundary_values():
    image = np.array([[119, 120, 121]], dtype=np.uint8)
    mask = segment_image(image, "fixed", 120)
    assert mask.tolist() == [[0, 0, 255]]


@pytest.mark.parametrize("filename", ["m21_favoravel.png", "m21_dificil.png"])
@pytest.mark.parametrize("method", ["fixed", "otsu"])
def test_real_project_inputs_produce_binary_masks(filename, method, tmp_path):
    image = cv2.imread(str(INPUT / filename), cv2.IMREAD_COLOR)
    assert image is not None
    mask = segment_image(image, method, 120)
    assert mask.shape == image.shape[:2]
    assert mask.ndim == 2
    assert set(np.unique(mask).tolist()).issubset({0, 255})
    stats = mask_statistics(mask)
    assert 0 <= stats["foreground_ratio"] <= 1


def test_unknown_method_fails():
    with pytest.raises(ValueError, match="desconhecido"):
        segment_image(np.zeros((2, 2), dtype=np.uint8), "magic", 120)


def test_invalid_threshold_fails():
    with pytest.raises(ValueError):
        segment_image(np.zeros((2, 2), dtype=np.uint8), "fixed", 300)


def test_cli_missing_input_fails_with_nonzero_code():
    result = subprocess.run(
        [sys.executable, "-m", "pdi_lab", "--operation", "segment",
         "--input", str(INPUT / "does_not_exist.png"), "--output", "unused.png",
         "--method", "fixed", "--threshold", "120"],
        cwd=ROOT, capture_output=True, text=True
    )
    assert result.returncode != 0
