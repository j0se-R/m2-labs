import numpy as np
import pytest

from pdi_lab.kernel import Kernel, read_kernel
from pdi_lab.operations import (
    convolution,
    convolution_float,
    laplacian,
    laplacian_response,
    laplacian_sharpen,
    mean_filter,
    sobel_components,
    sobel_magnitudes,
    weighted_mean,
)


def k3(values):
    return Kernel(3, tuple(float(v) for row in values for v in row))


def k5(values):
    return Kernel(5, tuple(float(v) for row in values for v in row))


def test_identity_kernel_reproduces_image_with_both_borders():
    image = np.arange(25, dtype=np.uint8).reshape(5, 5)
    identity = k3([[0, 0, 0], [0, 1, 0], [0, 0, 0]])
    np.testing.assert_array_equal(convolution(image, identity, "copy"), image)
    np.testing.assert_array_equal(convolution(image, identity, "replicate"), image)


def test_constant_image_is_preserved_by_normalized_3x3_and_5x5_means():
    image = np.full((7, 7), 128, dtype=np.uint8)
    np.testing.assert_array_equal(mean_filter(image, 3, "replicate"), image)
    np.testing.assert_array_equal(mean_filter(image, 5, "replicate"), image)
    np.testing.assert_array_equal(weighted_mean(image, "replicate"), image)


def test_copy_border_keeps_peripheral_pixels():
    image = np.array([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 255, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]], dtype=np.uint8)
    blur = mean_filter(image, 3, "copy")
    assert blur[0, 0] == image[0, 0]
    assert blur[0, 2] == image[0, 2]
    assert blur[2, 2] != image[2, 2]


def test_replicate_border_processes_peripheral_pixels():
    image = np.zeros((5, 5), dtype=np.uint8)
    image[0, 0] = 255
    blur = mean_filter(image, 3, "replicate")
    assert blur[0, 0] > 0
    assert blur[0, 1] > 0


def test_convolution_flips_kernel_for_true_convolution():
    image = np.array([[10, 20, 30], [40, 50, 60], [70, 80, 90]], dtype=np.uint8)
    kernel = k3([[0, 0, 0], [0, 0, 1], [0, 0, 0]])
    result = convolution_float(image, kernel, "copy")
    # Flipped kernel samples the upper-left neighbor at the center.
    assert result[1, 1] == 40


def test_laplacian_response_preserves_negative_values_before_visualization():
    image = np.full((5, 5), 128, dtype=np.uint8)
    image[2, 2] = 255
    response = laplacian_response(image, "copy")
    assert response[2, 2] < 0
    visual = laplacian(image, "copy")
    assert visual.dtype == np.uint8
    assert visual[2, 2] > 0


def test_laplacian_sharpen_stays_in_uint8_range():
    image = np.full((5, 5), 128, dtype=np.uint8)
    image[2, 2] = 255
    output = laplacian_sharpen(image, "replicate")
    assert output.dtype == np.uint8
    assert int(output.min()) >= 0
    assert int(output.max()) <= 255


def test_sobel_orientation_vertical_step():
    image = np.zeros((7, 7), dtype=np.uint8)
    image[:, 4:] = 255
    gx, gy = sobel_components(image, "replicate")
    # A vertical transition is mainly detected by Gx.
    assert float(np.max(np.abs(gx))) > 0
    assert float(np.max(np.abs(gy))) == 0


def test_sobel_orientation_horizontal_step():
    image = np.zeros((7, 7), dtype=np.uint8)
    image[4:, :] = 255
    gx, gy = sobel_components(image, "replicate")
    assert float(np.max(np.abs(gy))) > 0
    assert float(np.max(np.abs(gx))) == 0


def test_sobel_magnitudes_are_nonnegative_and_euclidean_is_not_greater_than_approx():
    image = np.arange(49, dtype=np.uint8).reshape(7, 7) * 4
    approx, euclidean = sobel_magnitudes(image, "replicate")
    assert approx.dtype == np.uint8
    assert euclidean.dtype == np.uint8
    assert np.all(euclidean.astype(np.int16) <= approx.astype(np.int16))


def test_kernel_5x5_is_accepted():
    kernel = k5([[0, 0, 0, 0, 0]] * 5)
    assert kernel.size == 5
    assert kernel.radius == 2


def test_invalid_kernel_is_rejected(tmp_path):
    empty = tmp_path / "empty.txt"
    empty.write_text("\n", encoding="utf-8")
    with pytest.raises(Exception):
        read_kernel(empty)

    even = tmp_path / "even.txt"
    even.write_text("1 0\n0 1\n", encoding="utf-8")
    with pytest.raises(Exception):
        read_kernel(even)

    nonsquare = tmp_path / "nonsquare.txt"
    nonsquare.write_text("1 2 3\n4 5 6\n", encoding="utf-8")
    with pytest.raises(Exception):
        read_kernel(nonsquare)
