from PIL import Image
import sys
import os
import csv


# ============================================================
# Utilidades
# ============================================================

def limitar(valor, minimo=0, maximo=255):
    """Limita o valor ao intervalo permitido."""
    return max(minimo, min(maximo, valor))


def arredondar(valor):
    """
    Arredondamento para o inteiro mais próximo.
    Para valores positivos, equivale a floor(valor + 0.5).
    """
    return int(valor + 0.5)


def verificar_imagem_cinza(img):
    """Verifica se a imagem possui um único canal de intensidade."""
    return img.mode == "L"


def validar_brilho(b):
    if not isinstance(b, (int, float)):
        raise ValueError("O brilho deve ser um número.")


def validar_contraste(alpha):
    if not isinstance(alpha, (int, float)):
        raise ValueError("O fator de contraste deve ser numérico.")

    if alpha < 0:
        raise ValueError("O fator de contraste não pode ser negativo.")


def validar_limiar(T):
    if not isinstance(T, (int, float)):
        raise ValueError("O limiar deve ser numérico.")

    if T < 0 or T > 255:
        raise ValueError("O limiar deve estar entre 0 e 255.")


# ============================================================
# 1. Ajuste de brilho
# ============================================================

def ajustar_brilho(img, b):
    """
    g(x,y) = f(x,y) + b

    Os valores são limitados para [0, 255].
    """
    if not verificar_imagem_cinza(img):
        raise ValueError(
            "O ajuste de brilho exige uma imagem em níveis de cinza."
        )

    validar_brilho(b)

    largura, altura = img.size
    resultado = Image.new("L", (largura, altura))

    for y in range(altura):
        for x in range(largura):
            f = img.getpixel((x, y))

            g = f + b
            g = arredondar(g)
            g = limitar(g)

            resultado.putpixel((x, y), g)

    return resultado


# ============================================================
# 2. Ajuste de contraste
# ============================================================

def ajustar_contraste(img, alpha):
    """
    g(x,y) = alpha * (f(x,y) - 128) + 128
    """
    if not verificar_imagem_cinza(img):
        raise ValueError(
            "O ajuste de contraste exige uma imagem em níveis de cinza."
        )

    validar_contraste(alpha)

    largura, altura = img.size
    resultado = Image.new("L", (largura, altura))

    for y in range(altura):
        for x in range(largura):
            f = img.getpixel((x, y))

            g = alpha * (f - 128) + 128

            g = arredondar(g)
            g = limitar(g)

            resultado.putpixel((x, y), g)

    return resultado


# ============================================================
# 3. Negativo
# ============================================================

def negativo(img):
    """
    g(x,y) = 255 - f(x,y)
    """
    if not verificar_imagem_cinza(img):
        raise ValueError(
            "O negativo exige uma imagem em níveis de cinza."
        )

    largura, altura = img.size
    resultado = Image.new("L", (largura, altura))

    for y in range(altura):
        for x in range(largura):
            f = img.getpixel((x, y))

            g = 255 - f

            resultado.putpixel((x, y), g)

    return resultado


# ============================================================
# 4. Limiarização binária
# ============================================================

def limiarizar(img, T):
    """
    g(x,y) = 0, quando f(x,y) < T
             255, quando f(x,y) >= T
    """
    if not verificar_imagem_cinza(img):
        raise ValueError(
            "A limiarização exige uma imagem em níveis de cinza."
        )

    validar_limiar(T)

    largura, altura = img.size
    resultado = Image.new("L", (largura, altura))

    for y in range(altura):
        for x in range(largura):
            f = img.getpixel((x, y))

            if f < T:
                g = 0
            else:
                g = 255

            resultado.putpixel((x, y), g)

    return resultado


# ============================================================
# 5. Histograma manual
# ============================================================

def calcular_histograma(img):
    """
    Cria manualmente um histograma com 256 posições.

    histograma[i] = quantidade de pixels com intensidade i
    """
    if not verificar_imagem_cinza(img):
        raise ValueError(
            "O histograma deve ser calculado sobre uma imagem em cinza."
        )

    histograma = [0] * 256

    largura, altura = img.size

    for y in range(altura):
        for x in range(largura):
            intensidade = img.getpixel((x, y))

            histograma[intensidade] += 1

    return histograma


def salvar_histograma_csv(histograma, caminho):
    """Salva o histograma no formato CSV."""
    with open(caminho, "w", newline="", encoding="utf-8") as arquivo:
        escritor = csv.writer(arquivo)

        escritor.writerow(["intensidade", "quantidade"])

        for intensidade in range(256):
            escritor.writerow([
                intensidade,
                histograma[intensidade]
            ])


# ============================================================
# Testes
# ============================================================

def criar_imagem_teste():
    """
    Cria uma pequena imagem sintética 4x4.

    Valores escolhidos para facilitar a conferência manual:
    0, 32, 64, 96,
    128, 160, 192, 224,
    255, 100, 150, 200,
    50, 75, 125, 175
    """
    img = Image.new("L", (4, 4))

    valores = [
        0, 32, 64, 96,
        128, 160, 192, 224,
        255, 100, 150, 200,
        50, 75, 125, 175
    ]

    indice = 0

    for y in range(4):
        for x in range(4):
            img.putpixel(
                (x, y),
                valores[indice]
            )
            indice += 1

    return img


def testar_brilho():
    print("\n=== TESTE DE BRILHO ===")

    img = Image.new("L", (5, 1))

    valores = [0, 50, 128, 200, 255]

    for x, valor in enumerate(valores):
        img.putpixel((x, 0), valor)

    negativo = ajustar_brilho(img, -50)
    positivo = ajustar_brilho(img, 50)

    resultado_negativo = []

    for x in range(5):
        resultado_negativo.append(
            negativo.getpixel((x, 0))
        )

    resultado_positivo = []

    for x in range(5):
        resultado_positivo.append(
            positivo.getpixel((x, 0))
        )

    # -50:
    # 0 -> 0 (saturação)
    # 50 -> 0
    # 128 -> 78
    # 200 -> 150
    # 255 -> 205
    assert resultado_negativo == [0, 0, 78, 150, 205]

    # +50:
    # 0 -> 50
    # 50 -> 100
    # 128 -> 178
    # 200 -> 250
    # 255 -> 255 (saturação)
    assert resultado_positivo == [50, 100, 178, 250, 255]

    print("Brilho -50:", resultado_negativo)
    print("Brilho +50:", resultado_positivo)
    print("OK: brilho e saturação conferidos.")


def testar_contraste():
    print("\n=== TESTE DE CONTRASTE ===")

    img = Image.new("L", (5, 1))

    valores = [0, 64, 128, 192, 255]

    for x, valor in enumerate(valores):
        img.putpixel((x, 0), valor)

    c05 = ajustar_contraste(img, 0.5)
    c10 = ajustar_contraste(img, 1.0)
    c15 = ajustar_contraste(img, 1.5)

    r05 = []
    r10 = []
    r15 = []

    for x in range(5):
        r05.append(c05.getpixel((x, 0)))
        r10.append(c10.getpixel((x, 0)))
        r15.append(c15.getpixel((x, 0)))

    assert r05 == [64, 96, 128, 160, 192]

    assert r10 == [0, 64, 128, 192, 255]

    # 1.5:
    # 0 -> -64 -> 0
    # 64 -> 32
    # 128 -> 128
    # 192 -> 224
    # 255 -> 318.5 -> 255
    assert r15 == [0, 32, 128, 224, 255]

    print("Alpha 0.5:", r05)
    print("Alpha 1.0:", r10)
    print("Alpha 1.5:", r15)

    print("OK: contraste reduzido, identidade e ampliado conferidos.")


def testar_negativo():
    print("\n=== TESTE DE NEGATIVO ===")

    img = Image.new("L", (4, 1))

    valores = [0, 50, 128, 255]

    for x, valor in enumerate(valores):
        img.putpixel((x, 0), valor)

    resultado = negativo(img)

    valores_resultado = []

    for x in range(4):
        valores_resultado.append(
            resultado.getpixel((x, 0))
        )

    assert valores_resultado == [255, 205, 127, 0]

    print("Entrada:", valores)
    print("Saída:  ", valores_resultado)
    print("OK: negativo conferido.")


def testar_limiarizacao():
    print("\n=== TESTE DE LIMIARIZAÇÃO ===")

    img = Image.new("L", (6, 1))

    valores = [0, 50, 100, 128, 200, 255]

    for x, valor in enumerate(valores):
        img.putpixel((x, 0), valor)

    t100 = limiarizar(img, 100)
    t200 = limiarizar(img, 200)

    r100 = []
    r200 = []

    for x in range(6):
        r100.append(t100.getpixel((x, 0)))
        r200.append(t200.getpixel((x, 0)))

    assert r100 == [0, 0, 255, 255, 255, 255]
    assert r200 == [0, 0, 0, 0, 255, 255]

    print("T=100:", r100)
    print("T=200:", r200)
    print("OK: dois limiares conferidos.")


def testar_histograma():
    print("\n=== TESTE DE HISTOGRAMA ===")

    img = Image.new("L", (4, 2))

    valores = [
        0, 0, 100, 100,
        255, 255, 128, 128
    ]

    indice = 0

    for y in range(2):
        for x in range(4):
            img.putpixel(
                (x, y),
                valores[indice]
            )
            indice += 1

    hist = calcular_histograma(img)

    assert hist[0] == 2
    assert hist[100] == 2
    assert hist[128] == 2
    assert hist[255] == 2

    # Todas as outras intensidades devem ser zero.
    for intensidade in range(256):
        if intensidade not in [0, 100, 128, 255]:
            assert hist[intensidade] == 0

    print("OK: histograma manual conferido.")


def testar_saturacao():
    print("\n=== TESTE DE SATURAÇÃO ===")

    img = Image.new("L", (4, 1))

    valores = [0, 10, 245, 255]

    for x, valor in enumerate(valores):
        img.putpixel((x, 0), valor)

    resultado = ajustar_brilho(img, 30)

    esperado = [
        30,     # 0 + 30
        40,     # 10 + 30
        255,    # 245 + 30 = 275 -> 255
        255     # 255 + 30 = 285 -> 255
    ]

    obtido = []

    for x in range(4):
        obtido.append(resultado.getpixel((x, 0)))

    assert obtido == esperado

    print("Entrada:", valores)
    print("Saída:  ", obtido)
    print("OK: saturação superior conferida.")


def executar_testes():
    testar_brilho()
    testar_contraste()
    testar_negativo()
    testar_limiarizacao()
    testar_histograma()
    testar_saturacao()

    print("\n====================================")
    print("TODOS OS TESTES FORAM APROVADOS")
    print("====================================")


# ============================================================
# Processamento da imagem real
# ============================================================

def processar_imagem(caminho_entrada, pasta_saida="saida"):
    if not os.path.exists(caminho_entrada):
        raise FileNotFoundError(
            f"Arquivo não encontrado: {caminho_entrada}"
        )

    os.makedirs(pasta_saida, exist_ok=True)

    try:
        img = Image.open(caminho_entrada)
    except Exception as erro:
        raise RuntimeError(
            f"Falha na leitura da imagem: {erro}"
        )

    if img.mode != "L":
        raise ValueError(
            f"A imagem precisa estar em níveis de cinza (L). "
            f"Modo encontrado: {img.mode}"
        )

    print("\n=== PROCESSAMENTO ===")
    print(f"Imagem: {caminho_entrada}")
    print(f"Dimensões: {img.width} x {img.height}")
    print(f"Modo: {img.mode}")
    print(f"Pixels: {img.width * img.height}")

    # --------------------------------------------------------
    # 1. Brilho
    # --------------------------------------------------------

    brilho_menos = ajustar_brilho(img, -50)
    brilho_mais = ajustar_brilho(img, 50)

    brilho_menos.save(
        os.path.join(pasta_saida, "brightness_minus_50.png")
    )

    brilho_mais.save(
        os.path.join(pasta_saida, "brightness_plus_50.png")
    )

    # --------------------------------------------------------
    # 2. Contraste
    # --------------------------------------------------------

    contraste_05 = ajustar_contraste(img, 0.5)
    contraste_10 = ajustar_contraste(img, 1.0)
    contraste_15 = ajustar_contraste(img, 1.5)

    contraste_05.save(
        os.path.join(pasta_saida, "contrast_0.5.png")
    )

    contraste_10.save(
        os.path.join(pasta_saida, "contrast_1.0.png")
    )

    contraste_15.save(
        os.path.join(pasta_saida, "contrast_1.5.png")
    )

    # --------------------------------------------------------
    # 3. Negativo
    # --------------------------------------------------------

    img_negativa = negativo(img)

    img_negativa.save(
        os.path.join(pasta_saida, "negative.png")
    )

    # --------------------------------------------------------
    # 4. Limiarização
    # --------------------------------------------------------

    limiar_80 = limiarizar(img, 80)
    limiar_160 = limiarizar(img, 160)

    limiar_80.save(
        os.path.join(pasta_saida, "threshold_80.png")
    )

    limiar_160.save(
        os.path.join(pasta_saida, "threshold_160.png")
    )

    # --------------------------------------------------------
    # 5. Histogramas
    # --------------------------------------------------------

    hist_original = calcular_histograma(img)
    hist_brilho = calcular_histograma(brilho_mais)
    hist_contraste = calcular_histograma(contraste_15)
    hist_negativo = calcular_histograma(img_negativa)

    salvar_histograma_csv(
        hist_original,
        os.path.join(
            pasta_saida,
            "hist_original.csv"
        )
    )

    salvar_histograma_csv(
        hist_brilho,
        os.path.join(
            pasta_saida,
            "hist_brightness_plus_50.csv"
        )
    )

    salvar_histograma_csv(
        hist_contraste,
        os.path.join(
            pasta_saida,
            "hist_contrast_1.5.csv"
        )
    )

    salvar_histograma_csv(
        hist_negativo,
        os.path.join(
            pasta_saida,
            "hist_negative.csv"
        )
    )

    print("\nArquivos gerados:")
    print("- brightness_minus_50.png")
    print("- brightness_plus_50.png")
    print("- contrast_0.5.png")
    print("- contrast_1.0.png")
    print("- contrast_1.5.png")
    print("- negative.png")
    print("- threshold_80.png")
    print("- threshold_160.png")
    print("- hist_original.csv")
    print("- hist_brightness_plus_50.csv")
    print("- hist_contrast_1.5.csv")
    print("- hist_negative.csv")


# ============================================================
# Programa principal
# ============================================================

def main():
    if len(sys.argv) < 2:
        print(
            "Uso:\n"
            "  python lab_m1_2.py caminho/para/imagem.png\n\n"
            "Para executar os testes:\n"
            "  python lab_m1_2.py --test\n"
        )
        return

    if sys.argv[1] == "--test":
        executar_testes()
        return

    caminho = sys.argv[1]

    try:
        processar_imagem(caminho)
    except Exception as erro:
        print(f"\nERRO: {erro}")
        sys.exit(1)


if __name__ == "__main__":
    main()