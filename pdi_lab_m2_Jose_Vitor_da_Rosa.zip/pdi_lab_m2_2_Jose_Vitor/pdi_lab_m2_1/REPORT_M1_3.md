# Mini relatorio — Laboratorio M1.3
Identificação
Estudante: José Vitor da Rosa
Matrícula: 8191042
Laboratório: M1.3 — Convolução e filtragem espacial
Linguagem: Python
1. Objetivo

Implementar manualmente operações de convolução e filtragem espacial em imagens em níveis de cinza, realizando o percurso dos vizinhos de cada pixel e tratando explicitamente as regiões próximas às bordas.

Foram implementados filtros de média, média ponderada, Laplaciano e Sobel, incluindo diferentes estratégias de tratamento das bordas.

2. Operações implementadas
Convolução genérica: percurso manual da vizinhança e multiplicação dos pixels pelos coeficientes do kernel.
Borda copy: pixels sem vizinhança completa mantêm o valor original.
Borda replicate: coordenadas fora da imagem são substituídas pela coordenada válida mais próxima.
Mean 3×3: média dos pixels da vizinhança.
Mean 5×5: média dos pixels de uma vizinhança maior.
Weighted mean 3×3: média ponderada utilizando coeficientes definidos para o filtro.
Laplaciano: cálculo da resposta assinada utilizando o kernel.
Laplacian sharpen: combinação da imagem original com a resposta do Laplaciano.
Sobel: cálculo manual de \(G_x\), \(G_y\), magnitude aproximada \(|G_x|+|G_y|\) e magnitude Euclidiana.

Os acumuladores da convolução utilizam float32, permitindo representar resultados negativos antes da etapa de visualização.

3. Testes realizados

| Teste               | Entrada                      | Operação            | Parâmetros                  | Resultado esperado ou critério de verificação       |
| ------------------- | ---------------------------- | ------------------- | --------------------------- | --------------------------------------------------- |
| Identidade          | `m1_gray_5x5.png`            | `convolution`       | identidade 3×3, `copy`      | Saída idêntica à entrada                            |
| Identidade          | `m1_gray_5x5.png`            | `convolution`       | identidade 3×3, `replicate` | Saída idêntica à entrada                            |
| Imagem constante    | imagem sintética             | `mean_filter`       | 3×3                         | Valor constante preservado                          |
| Imagem constante    | imagem sintética             | `mean_filter`       | 5×5                         | Valor constante preservado                          |
| Média ponderada     | imagem sintética             | `weighted_mean`     | 3×3                         | Valor constante preservado                          |
| Borda               | imagem sintética             | convolução          | `copy`                      | Borda preserva valores originais                    |
| Borda               | imagem sintética             | convolução          | `replicate`                 | Vizinhos externos replicados                        |
| Convolução          | imagem sintética             | `convolution`       | kernel assimétrico          | Kernel aplicado com inversão espacial               |
| Laplaciano          | `m1_gray_scene_256.png`      | `laplacian`         | `replicate`                 | Contornos destacados                                |
| Laplaciano assinado | imagem de teste              | resposta Laplaciana | —                           | Valores negativos preservados antes da visualização |
| Sharpen             | `m1_gray_scene_256.png`      | `laplacian_sharpen` | `replicate`                 | Contornos reforçados e saída em [0,255]             |
| Sobel vertical      | `m1_step_vertical_128.png`   | `sobel_gx`          | `replicate`                 | Resposta forte em bordas verticais                  |
| Sobel horizontal    | `m1_step_horizontal_128.png` | `sobel_gy`          | `replicate`                 | Resposta forte em bordas horizontais                |
| Sobel               | `m1_gray_scene_256.png`      | `sobel_approx`      | `replicate`                 | Mapa de bordas pela magnitude aproximada            |
| Sobel               | `m1_gray_scene_256.png`      | `sobel_euclidean`   | `replicate`                 | Mapa de bordas pela magnitude Euclidiana            |
| Kernel 5×5          | `m1_gray_scene_256.png`      | `convolution`       | kernel 5×5                  | Kernel aceito e aplicado                            |
| Kernel inválido     | imagem de teste              | `convolution`       | kernel vazio                | Operação rejeitada                                  |
| Kernel inválido     | imagem de teste              | `convolution`       | kernel par                  | Operação rejeitada                                  |
| Kernel inválido     | imagem de teste              | `convolution`       | kernel não quadrado         | Operação rejeitada                                  |

A suíte automatizada apresentou 30 testes aprovados.

4. Resultados

| Operação              | Entrada                      | Parâmetros  | Arquivo de saída              | Observação                                   |     |   |     |   |
| --------------------- | ---------------------------- | ----------- | ----------------------------- | -------------------------------------------- | --- | - | --- | - |
| Convolução identidade | `m1_gray_5x5.png`            | 3×3, `copy` | `m13_identity_3x3.png`        | Saída igual à entrada                        |     |   |     |   |
| Mean 3×3              | `m1_gray_scene_256.png`      | `copy`      | `m13_mean_3x3_copy.png`       | Suavização                                   |     |   |     |   |
| Mean 3×3              | `m1_gray_scene_256.png`      | `replicate` | `m13_mean_3x3_replicate.png`  | Suavização com tratamento de borda diferente |     |   |     |   |
| Weighted mean         | `m1_gray_scene_256.png`      | `replicate` | `m13_weighted_3x3.png`        | Suavização ponderada                         |     |   |     |   |
| Mean 5×5              | `m1_gray_scene_256.png`      | `replicate` | `m13_mean_5x5.png`            | Suavização mais intensa                      |     |   |     |   |
| Laplaciano            | `m1_gray_scene_256.png`      | `replicate` | `m13_laplacian.png`           | Contornos destacados                         |     |   |     |   |
| Sharpen               | `m1_gray_scene_256.png`      | `replicate` | `m13_laplacian_sharpen.png`   | Reforço de detalhes                          |     |   |     |   |
| Sobel Gx              | `m1_step_vertical_128.png`   | `replicate` | `m13_sobel_gx_vertical.png`   | Detecção de bordas verticais                 |     |   |     |   |
| Sobel Gy              | `m1_step_horizontal_128.png` | `replicate` | `m13_sobel_gy_horizontal.png` | Detecção de bordas horizontais               |     |   |     |   |
| Sobel aproximado      | `m1_gray_scene_256.png`      | `replicate` | `m13_sobel_approx.png`        | Magnitude (                                  | G_x | + | G_y | ) |
| Sobel Euclidiano      | `m1_gray_scene_256.png`      | `replicate` | `m13_sobel_euclidean.png`     | Magnitude \(\sqrt{G_x^2+G_y^2}\)             |     |   |     |   |
| Sobel                 | `m1_gray_scene_256.png`      | `replicate` | `m13_sobel.png`               | Saída principal do operador                  |     |   |     |   |

Também foi armazenada a resposta bruta do Laplaciano em float32 antes da conversão para visualização, permitindo verificar que os valores negativos não foram descartados durante o cálculo.

5. Análise técnica

Os filtros de média reduzem variações locais e produzem suavização. O filtro 5×5 utiliza uma vizinhança maior que o 3×3 e, por isso, apresenta uma suavização mais intensa.

As estratégias de borda copy e replicate produzem diferenças principalmente nas regiões próximas às extremidades da imagem. No conjunto de testes realizado, foram observadas diferenças entre essas duas estratégias nas bordas da imagem filtrada.

O Laplaciano responde principalmente a variações rápidas de intensidade, destacando contornos. Como sua resposta pode conter valores negativos, o cálculo foi mantido em float32 antes da visualização.

O sharpening utiliza a informação do Laplaciano para reforçar detalhes e contornos da imagem original.

O operador Sobel utiliza duas máscaras direcionais. \(G_x\) responde principalmente a variações na direção horizontal associadas a bordas verticais, enquanto \(G_y\) responde principalmente a variações na direção vertical associadas a bordas horizontais.

A magnitude aproximada utiliza:

$$ |G_x|+|G_y| $$

enquanto a magnitude Euclidiana utiliza:

$$ \sqrt{G_x^2+G_y^2} $$

As duas produzem mapas de bordas semelhantes, mas os valores numéricos não são necessariamente iguais.

A convolução foi implementada com inversão espacial do kernel, correspondendo à definição matemática de convolução.

6. Limitações

A implementação trabalha com imagens em tons de cinza uint8 e kernels quadrados de tamanho ímpar.

Os resultados visualizados são convertidos para uint8 e saturados no intervalo [0,255]. Essa conversão é adequada para imagens de saída, mas não deve ser aplicada antes da análise de respostas assinadas, como no Laplaciano.

O tratamento de bordas implementado limita-se às estratégias previstas no laboratório: copy e replicate.

7. Referências
Material e roteiro do Laboratório M1.3 — Convolução e filtragem espacial, Processamento de Imagens 2026-02.
Documentação do Python.
Documentação do NumPy.
Documentação do OpenCV.
Gonzalez e Woods, Digital Image Processing.