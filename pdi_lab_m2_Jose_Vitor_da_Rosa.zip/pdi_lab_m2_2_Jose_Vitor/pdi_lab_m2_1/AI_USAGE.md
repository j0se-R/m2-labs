# Declaração de uso de IA generativa

Foi utilizada assistência do ChatGPT para apoiar a implementação da operação `analyze`, a elaboração de testes automatizados, a atualização da documentação e a organização da análise dos resultados do laboratório M2.2. O código e os resultados devem ser executados e revisados pelo estudante, que é responsável por compreender, validar e adaptar a entrega às regras da disciplina.
