# Projeto-base Python — Laboratórios de Processamento de Imagens

Projeto em Python para os laboratórios de Processamento de Imagens (M1, M2.1 e M2.2). Inclui uma interface de linha de comando, operações de processamento, testes automatizados e exemplos de execução com imagens reais e sintéticas.

## 1. Requisitos

- Python 3.10 ou superior.
- CPython para Windows recomendado no Windows (por exemplo, Python 3.12 ou 3.13).
- `opencv-python-headless`.
- `pytest`.

No Windows, prefira o CPython para Windows em vez do interpretador Python do MSYS2/UCRT64, para que o `pip` instale os wheels binários compatíveis do OpenCV.

Confira o interpretador:

```powershell
python --version
python -c "import sys; print(sys.executable)"
```

## 2. Instalação

Execute os comandos a partir da raiz do projeto — a pasta que contém `pyproject.toml`.

### Windows — PowerShell

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

Se já existir um ambiente virtual compatível, ative-o e execute os comandos de instalação necessários. Não é necessário criar outro ambiente virtual.

### Linux/macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

Se o `pip` informar que está construindo `opencv-python-headless` a partir do código-fonte, confira a versão e a origem do interpretador antes de prosseguir.

## 3. Estrutura do projeto

```text
src/pdi_lab/       Código do pacote e operações
tests/             Testes automatizados
images/input/      Imagens originais de entrada
images/output/     Saídas de imagem usadas em exemplos
kernels/           Kernels textuais para convolução
results/           Resultados dos experimentos (PNG, CSV e JSON)
README.md          Instruções do projeto
REPORT_M2_2.md     Relatório do laboratório M2.2
AI_USAGE.md        Registro de uso de ferramentas de IA, se exigido
lab.json           Metadados do laboratório
pyproject.toml     Configuração do pacote
requirements.txt   Dependências
```

Os nomes e arquivos presentes podem variar conforme a versão do projeto entregue. Os comandos abaixo usam os caminhos relativos à raiz do projeto.

## 4. Testes

Execute a suíte completa com:

```powershell
python -m pytest
```

Na última execução registrada para esta versão, **45 testes passaram**. Execute novamente o comando após qualquer alteração para confirmar o estado atual do projeto.

Também é possível consultar a interface da CLI:

```powershell
python -m pdi_lab --version
python -m pdi_lab --help
```

## 5. Laboratórios M1

O projeto-base contempla operações de inspeção de imagens, níveis de cinza, transformações de intensidade, histogramas, convolução e filtragem espacial. Os exemplos disponíveis dependem das imagens e dos kernels presentes no projeto.

Exemplo de quantização:

```powershell
python -m pdi_lab --operation quantize --input images/input/m1_gray_ramp_256.png --output images/output/quant_8.png --levels 8
```

Exemplo de filtro da média:

```powershell
python -m pdi_lab --operation mean_filter --input images/input/m1_gray_scene_256.png --output images/output/mean_3x3.png --size 3 --border replicate
```

Se algum arquivo de entrada não estiver presente na versão do projeto, substitua o caminho pelo de uma imagem compatível existente.

## 6. Laboratório M2.1 — Máscara binária e segmentação

A operação `segment` gera uma máscara binária a partir de uma imagem de entrada. A implementação documentada considera intensidades acima do limiar como primeiro plano; para objetos escuros, confira a máscara resultante e verifique se é necessário inverter a lógica de segmentação.

### Limiar fixo

As imagens sintéticas de demonstração ficam em `images/input/`:

```powershell
python -m pdi_lab --operation segment --input images/input/m21_favoravel.png --output results/m21_sintetica_favoravel_mask.png --method fixed --threshold 120
python -m pdi_lab --operation segment --input images/input/m21_dificil.png --output results/m21_sintetica_dificil_mask.png --method fixed --threshold 120
```

As imagens reais utilizadas nos experimentos são `m21_favoravel1.png` e `m21_dificil1.png`, também em `images/input/`:

```powershell
python -m pdi_lab --operation segment --input images/input/m21_favoravel1.png --output results/m21_favoravel_mask.png --method fixed --threshold 120
python -m pdi_lab --operation segment --input images/input/m21_dificil1.png --output results/m21_dificil_mask.png --method fixed --threshold 120
```

### Limiar de Otsu

O método Otsu calcula o limiar automaticamente:

```powershell
python -m pdi_lab --operation segment --input images/input/m21_favoravel.png --output results/m21_favoravel_otsu_mask.png --method otsu
python -m pdi_lab --operation segment --input images/input/m21_dificil.png --output results/m21_dificil_otsu_mask.png --method otsu
```

`--method` aceita `fixed` ou `otsu`. Para `fixed`, informe `--threshold` entre 0 e 255. Confira sempre visualmente as máscaras produzidas.

## 7. Laboratório M2.2 — Componentes conexos e sequência morfológica

A operação `analyze` recebe uma máscara binária PNG de um canal com valores 0 e 255. O argumento `--output` deve ser um **prefixo de saída**, não o nome de um único arquivo. A análise registra os componentes conexos, suas áreas e caixas delimitadoras, aplica a sequência morfológica selecionada e produz arquivos de resultado.

### Parâmetros utilizados nos experimentos

- `--connectivity 8`: conectividade principal; o resumo também registra a contagem inicial com conectividade 4.
- `--min-area 100`: limite de área para marcar componentes como mantidos nos CSVs.
- `--kernel-size 3`: elemento estruturante retangular de 3 × 3.
- `--iterations 1`: uma iteração por estágio.
- `--sequence open-close`: abertura seguida de fechamento.

### 7.1 Gerar as máscaras M2.1

Imagens sintéticas:

```powershell
python -m pdi_lab --operation segment --input images/input/m21_favoravel.png --output results/m21_sintetica_favoravel_mask.png --method fixed --threshold 120
python -m pdi_lab --operation segment --input images/input/m21_dificil.png --output results/m21_sintetica_dificil_mask.png --method fixed --threshold 120
```

Imagens reais:

```powershell
python -m pdi_lab --operation segment --input images/input/m21_favoravel1.png --output results/m21_favoravel_mask.png --method fixed --threshold 120
python -m pdi_lab --operation segment --input images/input/m21_dificil1.png --output results/m21_dificil_mask.png --method fixed --threshold 120
```

### 7.2 Analisar as máscaras

Imagens reais:

```powershell
python -m pdi_lab --operation analyze --input results/m21_favoravel_mask.png --output results/m22_favoravel --connectivity 8 --min-area 100 --kernel-size 3 --iterations 1 --sequence open-close
python -m pdi_lab --operation analyze --input results/m21_dificil_mask.png --output results/m22_dificil --connectivity 8 --min-area 100 --kernel-size 3 --iterations 1 --sequence open-close
```

Imagens sintéticas:

```powershell
python -m pdi_lab --operation analyze --input results/m21_sintetica_favoravel_mask.png --output results/m22_sintetica_favoravel --connectivity 8 --min-area 100 --kernel-size 3 --iterations 1 --sequence open-close
python -m pdi_lab --operation analyze --input results/m21_sintetica_dificil_mask.png --output results/m22_sintetica_dificil --connectivity 8 --min-area 100 --kernel-size 3 --iterations 1 --sequence open-close
```

### Parâmetros da operação `analyze`

- `--connectivity`: `4` ou `8`; padrão `8`.
- `--min-area`: área mínima, em pixels, para marcar um componente como mantido; nos experimentos documentados foi usado `100`.
- `--kernel-size`: tamanho ímpar do elemento estruturante, mínimo `3`; nos experimentos foi usado `3`.
- `--iterations`: número de iterações por estágio; nos experimentos foi usado `1`.
- `--sequence`: `open-close` ou `close-open`. `open-close` aplica abertura e depois fechamento; `close-open` aplica a ordem inversa.

A filtragem por área marca nos CSVs quais componentes atingem o limite. Não interprete essa marcação, isoladamente, como remoção desses componentes da máscara final.

### Arquivos produzidos

Para o prefixo `results/m22_favoravel`, a operação produz arquivos com esse prefixo, incluindo:

- `m22_favoravel_initial.png`: máscara inicial.
- `m22_favoravel_open.png`: resultado intermediário para a sequência `open-close` (para `close-open`, o estágio intermediário usa `close` no nome).
- `m22_favoravel_final.png`: máscara após a sequência morfológica.
- `m22_favoravel_initial.csv` e `m22_favoravel_final.csv`: informações dos componentes, incluindo áreas, caixas delimitadoras, centroides e indicação `kept`.
- `m22_favoravel_labels.png`: visualização dos rótulos dos componentes.
- `m22_favoravel_summary.json`: parâmetros, contagens, áreas e caminhos das saídas.

O rótulo 0 representa o fundo e não é exportado como objeto. O programa também verifica a correspondência entre a soma das áreas dos componentes e a quantidade de pixels de primeiro plano na máscara analisada.

## 8. Resultados e relatório

O relatório `REPORT_M2_2.md` documenta os parâmetros e a análise dos quatro casos:

- imagem real favorável;
- imagem real difícil;
- imagem sintética favorável;
- imagem sintética difícil.

Os resultados devem ser interpretados com inspeção visual das máscaras iniciais, das máscaras finais e das imagens de rótulos. Uma redução no número de componentes ou nos pixels de primeiro plano não garante, por si só, uma segmentação melhor: a morfologia também pode eliminar partes válidas ou unir regiões próximas.

