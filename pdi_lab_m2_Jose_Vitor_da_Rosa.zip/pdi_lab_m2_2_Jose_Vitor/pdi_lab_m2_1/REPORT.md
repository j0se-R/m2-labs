# Mini relatório — Laboratório M2.1: Máscara binária e segmentação

## Alvo e imagens

O alvo demonstrativo são três objetos aproximadamente circulares e claros, tratados como primeiro plano. `m21_favoravel.png` apresenta objetos claros sobre fundo escuro uniforme; `m21_dificil.png` apresenta variação gradual de iluminação, textura/ruído e sombras. As duas imagens contêm múltiplos objetos discerníveis.

**Importante:** as duas imagens incluídas nesta versão são cenas sintéticas criadas para tornar os testes reproduzíveis; não são fotografias reais. Antes da entrega final da disciplina, substitua-as por duas imagens próprias ou fornecidas com permissão de uso, mantendo uma favorável e outra com dificuldade real. Preserve os originais e atualize as observações e os resultados abaixo com base nas novas imagens.

## Configurações comparadas

| Configuração | Conversão/pré-processamento | Parâmetros |
|---|---|---|
| Limiar fixo | Imagem BGR convertida para cinza com `cv2.cvtColor` | `--method fixed --threshold 120`; pixels acima de 120 viram 255; os demais viram 0 |
| Otsu | Mesma conversão para cinza; sem filtro adicional | `--method otsu`; limiar calculado automaticamente pelo histograma |

Não foi aplicada inversão, pois a configuração demonstrativa considera os objetos claros como primeiro plano. A implementação salva PNG em escala de cinza, com dimensões preservadas e apenas os valores 0 e 255.

## Proporção de primeiro plano

| Imagem | Configuração | Pixels de primeiro plano | Proporção |
|---|---|---:|---:|
| `m21_favoravel.png` | Fixo (120) | 11.823 | 15,39% |
| `m21_favoravel.png` | Otsu | 11.823 | 15,39% |
| `m21_dificil.png` | Fixo (120) | 31.457 | 40,96% |
| `m21_dificil.png` | Otsu | 32.046 | 41,73% |

A proporção é uma medida quantitativa da área classificada como primeiro plano, não uma medida de acurácia. Não existe máscara de referência anotada neste projeto; portanto, não se declara acurácia, precisão ou revocação.

## Figuras e inspeção visual

### Cena favorável — original

![Cena favorável](images/input/m21_favoravel.png)

### Cena favorável — máscara por limiar fixo

![Máscara fixa favorável](images/output/m21_favoravel_fixed_mask.png)

### Cena favorável — máscara por Otsu

![Máscara Otsu favorável](images/output/m21_favoravel_otsu_mask.png)

### Cena difícil — original

![Cena difícil](images/input/m21_dificil.png)

### Cena difícil — máscara por limiar fixo

![Máscara fixa difícil](images/output/m21_dificil_fixed_mask.png)

### Cena difícil — máscara por Otsu

![Máscara Otsu difícil](images/output/m21_dificil_otsu_mask.png)

### Sobreposição para localizar regiões classificadas como primeiro plano

![Sobreposição fixa difícil](images/output/m21_dificil_fixed_overlay.png)

Na sobreposição, as regiões vermelhas representam pixels classificados como primeiro plano. Como não há anotação de referência, isso permite inspecionar visualmente a segmentação, mas não classificar de forma definitiva cada pixel como falso positivo ou falso negativo.

## Discussão

**(a) Em que casos o limiar fixo funcionou ou falhou?** Na cena favorável, o limiar 120 e Otsu produziram máscaras com a mesma proporção de primeiro plano. Na cena difícil, a iluminação gradual e a textura fazem com que mais regiões do fundo ultrapassem o limiar. Otsu selecionou uma área ligeiramente maior, mas uma área maior não significa necessariamente uma segmentação melhor.

**(b) Qual parâmetro foi mais sensível?** O limiar em tons de cinza é o parâmetro diretamente ajustável no método fixo: alterá-lo muda quais intensidades passam a ser primeiro plano. A cena com iluminação variável evidencia essa sensibilidade. Otsu remove a escolha manual do valor, mas continua dependendo do histograma e não resolve automaticamente fundos complexos.

**(c) Quais erros podem atrapalhar a contagem no M2.2?** Objetos separados que se fundem à máscara podem ser contados como um só; sombras ou regiões do fundo classificadas como primeiro plano podem ser contadas como objetos; falhas dentro de um objeto podem fragmentá-lo; e objetos encostados podem não ter uma fronteira binária que permita separá-los. Esses casos justificam revisar as máscaras e selecionar a configuração de trabalho com base nas imagens reais.

## Validação

A implementação e os testes verificam que a máscara possui a mesma largura e altura da entrada, um único canal e somente os valores `{0, 255}`. A saída é PNG sem perdas. O programa também imprime a contagem de pixels de primeiro plano e sua proporção.

## Configuração de trabalho provisória

Para a cena favorável, fixo com limiar 120 é uma escolha simples e reproduzível. Para a cena difícil, não se deve escolher automaticamente Otsu só porque ele é automático: compare as máscaras das imagens reais e escolha a configuração que melhor preserve os objetos e rejeite o fundo. A decisão final do projeto deve ser registrada após essa inspeção.

---

# Laboratório M2.2 — Componentes conexos e sequência morfológica

## Alvo e máscaras utilizadas

A análise parte das máscaras binárias geradas pela operação `segment` do próprio projeto no M2.1. Os objetos de primeiro plano são os pixels brancos (255), e o fundo corresponde aos pixels pretos (0). As imagens incluídas no ZIP são cenas sintéticas de teste, não fotografias reais; os resultados desta seção documentam a execução reproduzível sobre essas máscaras.

Foram usadas `images/output/m21_favoravel_fixed_mask.png` e `images/output/m21_dificil_fixed_mask.png`, ambas produzidas por limiar fixo 120. A primeira contém três regiões claras bem separadas; a segunda contém ruído e regiões de fundo conectadas, sendo um caso difícil para a contagem.

## Configuração da sequência morfológica

A sequência aplicada foi **abertura seguida de fechamento** (`open-close`), usando elemento estruturante retangular de 3 × 3 pixels e uma iteração por estágio. A máscara inicial foi preservada sem alteração.

- **Abertura (erosão seguida de dilatação):** escolhida para remover componentes muito pequenos e ruído isolado que não resista ao elemento estruturante.
- **Fechamento (dilatação seguida de erosão):** aplicado depois da abertura para tentar preencher pequenas lacunas e furos no primeiro plano. Pode, como efeito indesejado, unir regiões que estejam muito próximas.
- **Conectividade de análise final:** 8. A contagem inicial foi calculada tanto com conectividade 4 quanto com conectividade 8.
- **Filtro de área:** `min-area = 20` pixels. Um componente é marcado `kept=true` se sua área for maior ou igual a 20. O filtro é registrado no CSV e nas contagens; não altera os pixels da máscara final.

Com conectividade 4, pixels que só se tocam pelas diagonais pertencem a componentes distintos. Com conectividade 8, o contato diagonal também conecta os componentes. Por isso, a conectividade 8 geralmente produz a mesma quantidade ou menos componentes que a conectividade 4.

## Resultados antes e depois

| Imagem | Componentes iniciais (4) | Componentes iniciais (8) | Inicial após filtro (8) | Componentes finais brutos (8) | Finais após filtro | Área inicial (px) | Área final (px) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Favorável | 3 | 3 | 3 | 3 | 3 | 11.823 | 11.823 |
| Difícil | 1.048 | 510 | 7 | 24 | 5 | 31.457 | 27.118 |

A soma das áreas dos componentes brutos foi verificada contra a quantidade de pixels brancos em cada máscara. Na máscara favorável, as áreas somam 11.823 pixels antes e depois. Na máscara difícil, somam 31.457 pixels inicialmente e 27.118 pixels depois da sequência. A redução na área decorre principalmente da abertura, que remove regiões pequenas e pixels de ruído.

## Figuras por estágio

### Caso favorável

| Máscara inicial | Após abertura | Máscara final após fechamento | Rótulos e caixas finais |
|---|---|---|---|
| ![Máscara inicial favorável](results/m22_favoravel_initial.png) | ![Após abertura favorável](results/m22_favoravel_open.png) | ![Máscara final favorável](results/m22_favoravel_final.png) | ![Componentes favoráveis](results/m22_favoravel_labels.png) |

A sequência não alterou a área nem a quantidade de componentes neste caso: os três objetos já eram grandes e separados, sem ruído pequeno relevante para o elemento estruturante utilizado. A contagem de três componentes é compatível com a interpretação visual das três regiões.

### Caso difícil

| Máscara inicial | Após abertura | Máscara final após fechamento | Rótulos e caixas finais |
|---|---|---|---|
| ![Máscara inicial difícil](results/m22_dificil_initial.png) | ![Após abertura difícil](results/m22_dificil_open.png) | ![Máscara final difícil](results/m22_dificil_final.png) | ![Componentes difíceis](results/m22_dificil_labels.png) |

A máscara difícil continha muito ruído e uma região extensa de primeiro plano conectada ao fundo. A sequência reduziu a contagem bruta de 510 para 24 componentes (conectividade 8), mas não isolou completamente os objetos. Após o filtro de área, cinco componentes permaneceram, ainda não correspondendo de forma confiável à interpretação humana de três objetos.

## Discussão dos efeitos

**Caso em que a sequência ajuda:** na máscara difícil, a abertura removeu parte do ruído pequeno, reduziu a área de primeiro plano de 31.457 para 27.118 pixels ao final e diminuiu bastante a quantidade de componentes. Isso torna a máscara menos fragmentada, embora não resolva a região conectada ao fundo.

**Caso em que a sequência não resolve ou pode prejudicar:** a grande região conectada na máscara difícil permaneceu como um componente extenso depois das operações. O fechamento também pode conectar objetos próximos ou engrossar contornos, dependendo da distância entre as regiões. A sequência morfológica não consegue recuperar uma separação que já não existe na máscara inicial; aumentar o elemento estruturante pode eliminar detalhes pequenos ou fundir objetos.

**Contagem e interpretação humana:** na imagem favorável, três componentes correspondem às três regiões claras visíveis. Na imagem difícil, a contagem final após filtro foi cinco, mas isso não significa que existam cinco objetos reais: há uma região de fundo conectada e pequenos componentes residuais. Componentes conexos descrevem regiões da máscara, não necessariamente objetos físicos. Contato, sobreposição, falsos positivos e fragmentação impedem equiparar automaticamente a contagem algorítmica ao número real de objetos.

## Arquivos e reprodutibilidade

Os arquivos `_initial.png`, `_open.png`, `_final.png`, `_initial.csv`, `_final.csv`, `_labels.png` e `_summary.json` foram gerados na pasta `results/`. Os CSVs incluem `label`, `area`, `x`, `y`, `width`, `height`, `cx`, `cy` e `kept`; o rótulo 0 (fundo) é excluído. Os resumos guardam conectividade, sequência, elemento estruturante, iterações, contagens brutas e filtradas e áreas de primeiro plano.

Os testes automatizados incluem o caso de dois pixels diagonais (dois componentes com conectividade 4 e um com conectividade 8), remoção de ruído pela abertura, preenchimento de um furo pelo fechamento, máscara vazia, objeto tocando a borda, parâmetro de conectividade inválido e validação da soma das áreas dos componentes.

A limitação principal desta execução é a qualidade da máscara inicial do caso difícil. Para a etapa M2.2 com fotografias reais, será necessário gerar máscaras adequadas no M2.1 e comparar a contagem resultante com a inspeção visual ou uma contagem manual documentada. Não foi usada uma máscara de referência; portanto, não são declaradas métricas de acurácia, precisão ou revocação.
