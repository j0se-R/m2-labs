from __future__ import annotations

import csv
import json
from pathlib import Path

import cv2
import numpy as np


def validate_binary_mask(mask: np.ndarray) -> None:
    if mask is None or mask.size == 0:
        raise ValueError("A mascara de entrada esta vazia.")
    if mask.ndim != 2:
        raise ValueError("A mascara deve ter um unico canal (tons de cinza).")
    if mask.dtype != np.uint8:
        raise ValueError("A mascara deve usar pixels uint8.")
    if not set(np.unique(mask).tolist()).issubset({0, 255}):
        raise ValueError("A mascara deve conter somente os valores 0 e 255.")


def component_rows(mask: np.ndarray, connectivity: int, min_area: int) -> tuple[list[dict], dict]:
    validate_binary_mask(mask)
    if connectivity not in (4, 8):
        raise ValueError("--connectivity deve ser 4 ou 8.")
    if min_area < 0:
        raise ValueError("--min-area deve ser um inteiro nao negativo.")

    count, labels, stats, centroids = cv2.connectedComponentsWithStats(
        (mask == 255).astype(np.uint8), connectivity=connectivity, ltype=cv2.CV_32S
    )
    rows = []
    for label in range(1, count):  # rótulo 0 é o fundo e não é exportado
        x, y, width, height, area = [int(v) for v in stats[label]]
        cx, cy = [float(v) for v in centroids[label]]
        rows.append({
            "label": label,
            "area": area,
            "x": x,
            "y": y,
            "width": width,
            "height": height,
            "cx": round(cx, 4),
            "cy": round(cy, 4),
            "kept": area >= min_area,
        })

    foreground_pixels = int(np.count_nonzero(mask == 255))
    if sum(row["area"] for row in rows) != foreground_pixels:
        raise ValueError("Validacao interna falhou: soma das areas difere dos pixels de primeiro plano.")

    details = {
        "components_raw": len(rows),
        "components_filtered": sum(bool(row["kept"]) for row in rows),
        "foreground_pixels": foreground_pixels,
        "foreground_ratio": foreground_pixels / mask.size if mask.size else 0.0,
        "total_pixels": int(mask.size),
        "sum_component_areas": int(sum(row["area"] for row in rows)),
        "foreground_pixels_kept_components": int(sum(row["area"] for row in rows if row["kept"])),
    }
    return rows, details


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["label", "area", "x", "y", "width", "height", "cx", "cy", "kept"]
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _label_visualization(mask: np.ndarray, connectivity: int, rows: list[dict]) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        (mask == 255).astype(np.uint8), connectivity=connectivity, ltype=cv2.CV_32S
    )
    visual = np.zeros((*mask.shape, 3), dtype=np.uint8)
    for label in range(1, count):
        # Paleta determinística e não preta para cada componente.
        color = (int((37 * label + 70) % 220 + 35),
                 int((67 * label + 40) % 220 + 35),
                 int((97 * label + 10) % 220 + 35))
        visual[labels == label] = color
    for row in rows:
        x, y = row["x"], row["y"]
        width, height = row["width"], row["height"]
        color = (40, 230, 40) if row["kept"] else (0, 0, 255)
        cv2.rectangle(visual, (x, y), (x + width - 1, y + height - 1), color, 1)
        cv2.putText(visual, str(row["label"]), (x, max(10, y - 3)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
    return visual


def analyze_mask(mask: np.ndarray, output_prefix: str | Path, connectivity: int = 8,
                 min_area: int = 20, kernel_size: int = 3, iterations: int = 1,
                 sequence: str = "open-close") -> dict:
    """Analisa uma máscara binária e grava estágios, CSVs, rótulos e resumo."""
    validate_binary_mask(mask)
    if connectivity not in (4, 8):
        raise ValueError("--connectivity deve ser 4 ou 8.")
    if min_area < 0:
        raise ValueError("--min-area deve ser um inteiro nao negativo.")
    if kernel_size < 3 or kernel_size % 2 == 0:
        raise ValueError("--kernel-size deve ser um inteiro impar >= 3.")
    if iterations < 1:
        raise ValueError("--iterations deve ser >= 1.")
    if sequence not in {"open-close", "close-open"}:
        raise ValueError("--sequence deve ser open-close ou close-open.")

    prefix = Path(output_prefix)
    prefix.parent.mkdir(parents=True, exist_ok=True)
    initial = mask.copy()
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))

    initial_rows, initial_stats = component_rows(initial, connectivity, min_area)
    initial_count_4 = component_rows(initial, 4, min_area)[1]["components_raw"]
    initial_count_8 = component_rows(initial, 8, min_area)[1]["components_raw"]

    first_name, second_name = sequence.split("-")
    first_op = cv2.MORPH_OPEN if first_name == "open" else cv2.MORPH_CLOSE
    second_op = cv2.MORPH_OPEN if second_name == "open" else cv2.MORPH_CLOSE
    first_stage = cv2.morphologyEx(initial, first_op, kernel, iterations=iterations)
    final_mask = cv2.morphologyEx(first_stage, second_op, kernel, iterations=iterations)
    # Garante o contrato binário explicitamente após as operações.
    first_stage = np.where(first_stage > 0, 255, 0).astype(np.uint8)
    final_mask = np.where(final_mask > 0, 255, 0).astype(np.uint8)

    final_rows, final_stats = component_rows(final_mask, connectivity, min_area)
    # A visualização e o CSV usam os mesmos rótulos da conectividade escolhida.
    labels_visual = _label_visualization(final_mask, connectivity, final_rows)

    def write_image(path: Path, image: np.ndarray) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(path), image):
            raise OSError(f"Nao foi possivel salvar: {path}")

    paths = {
        "initial_mask": Path(f"{prefix}_initial.png"),
        "first_stage": Path(f"{prefix}_{first_name}.png"),
        "final_mask": Path(f"{prefix}_final.png"),
        "initial_csv": Path(f"{prefix}_initial.csv"),
        "final_csv": Path(f"{prefix}_final.csv"),
        "labels": Path(f"{prefix}_labels.png"),
        "summary": Path(f"{prefix}_summary.json"),
    }
    write_image(paths["initial_mask"], initial)
    write_image(paths["first_stage"], first_stage)
    write_image(paths["final_mask"], final_mask)
    write_image(paths["labels"], labels_visual)
    _write_csv(paths["initial_csv"], initial_rows)
    _write_csv(paths["final_csv"], final_rows)

    summary = {
        "input_mask": "binary PNG mask",
        "connectivity_selected": connectivity,
        "initial_components_connectivity_4": initial_count_4,
        "initial_components_connectivity_8": initial_count_8,
        "min_area_pixels": min_area,
        "morphology": {
            "sequence": sequence,
            "kernel_shape": "rect",
            "kernel_size": [kernel_size, kernel_size],
            "iterations_per_stage": iterations,
            "stages": [first_name, second_name],
        },
        "initial": initial_stats,
        "final": final_stats,
        "outputs": {key: str(path).replace("\\", "/") for key, path in paths.items()},
    }
    with paths["summary"].open("w", encoding="utf-8") as file:
        json.dump(summary, file, ensure_ascii=False, indent=2)
        file.write("\n")
    return summary
