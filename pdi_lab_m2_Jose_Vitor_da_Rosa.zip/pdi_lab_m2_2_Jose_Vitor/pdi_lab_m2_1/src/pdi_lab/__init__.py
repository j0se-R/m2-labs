__version__ = "0.3.0"
CONTRACT_VERSION = 2
