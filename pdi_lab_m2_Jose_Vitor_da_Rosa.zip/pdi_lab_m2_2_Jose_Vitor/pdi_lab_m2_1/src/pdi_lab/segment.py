from __future__ import annotations

import cv2
import numpy as np


def segment_image(image: np.ndarray, method: str = "fixed", threshold: int = 120) -> np.ndarray:
    """Produz máscara binária uint8: 0=fundo e 255=primeiro plano."""
    if image is None or image.size == 0:
        raise ValueError("Imagem vazia.")
    if image.dtype != np.uint8:
        raise ValueError("A segmentacao exige imagem uint8.")
    if image.ndim == 2:
        gray = image
    elif image.ndim == 3 and image.shape[2] == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    elif image.ndim == 3 and image.shape[2] == 4:
        gray = cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
    else:
        raise ValueError("Formato de imagem nao suportado para segmentacao.")

    if method == "fixed":
        if not 0 <= threshold <= 255:
            raise ValueError("--threshold deve estar entre 0 e 255.")
        _, mask = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    elif method == "otsu":
        _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    else:
        raise ValueError(f"Metodo de segmentacao desconhecido: {method}. Use fixed ou otsu.")
    return mask


def mask_statistics(mask: np.ndarray) -> dict[str, float | int]:
    if mask.ndim != 2 or not set(np.unique(mask).tolist()).issubset({0, 255}):
        raise ValueError("A mascara deve ter um canal e conter somente 0 e 255.")
    foreground = int(np.count_nonzero(mask == 255))
    total = int(mask.size)
    return {"foreground_pixels": foreground, "total_pixels": total,
            "foreground_ratio": foreground / total if total else 0.0}
