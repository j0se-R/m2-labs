from __future__ import annotations

import sys

import numpy as np

from . import exit_code
from .cli import CliOptions
from .image_io import read_image, write_image
from .parameters import parameter_as_border, parameter_as_float, parameter_as_int, parameter_as_path
from .kernel import read_kernel, Kernel
from .result_io import write_histogram_csv, write_json_object
from .segment import segment_image, mask_statistics
from .analyze import analyze_mask


KNOWN_OPERATIONS = {
    "inspect", "copy", "channel_b", "channel_g", "channel_r",
    "grayscale_average", "grayscale_weighted", "quantize",
    "brightness", "contrast", "negative", "threshold", "histogram",
    "convolution", "mean_filter", "weighted_mean", "laplacian", "laplacian_sharpen",
    "sobel", "sobel_gx", "sobel_gy", "sobel_approx", "sobel_euclidean", "segment", "analyze",
}


def is_known_operation(operation: str) -> bool:
    return operation in KNOWN_OPERATIONS


def _require_grayscale_uint8(image: np.ndarray) -> None:
    if image.ndim != 2:
        raise ValueError("As operacoes M1.2 exigem uma imagem em tons de cinza (1 canal).")
    if image.dtype != np.uint8:
        raise ValueError("As operacoes M1.2 exigem uma imagem de 8 bits (uint8).")


def _require_color_bgr_uint8(image: np.ndarray) -> None:
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("A operacao exige uma imagem colorida BGR com 3 canais.")
    if image.dtype != np.uint8:
        raise ValueError("A operacao exige uma imagem de 8 bits (uint8).")


def _clamp(value: float) -> int:
    if value < 0.0:
        return 0
    if value > 255.0:
        return 255
    return int(value + 0.5)


# ---------------- M1.1 ----------------


def inspect_image(image: np.ndarray) -> dict[str, str]:
    """Calcula as informacoes solicitadas pela M1.1 sem usar agregacoes prontas."""
    if image.ndim not in (2, 3):
        raise ValueError("Tipo de imagem incompatível para inspecao.")
    if image.dtype != np.uint8:
        raise ValueError("A inspecao da M1.1 exige uma imagem de 8 bits (uint8).")

    height, width = image.shape[:2]
    channels = 1 if image.ndim == 2 else image.shape[2]
    pixels = width * height

    result: dict[str, str] = {
        "width": str(width),
        "height": str(height),
        "channels": str(channels),
        "dtype": str(image.dtype),
        "pixels": str(pixels),
    }

    if image.ndim == 2:
        minimum = 255
        maximum = 0
        total = 0
        for y in range(height):
            for x in range(width):
                value = int(image[y, x])
                minimum = min(minimum, value)
                maximum = max(maximum, value)
                total += value
        result["min"] = str(minimum)
        result["max"] = str(maximum)
        result["mean"] = str(total / pixels if pixels else 0.0)
    else:
        names = ("b", "g", "r")
        for channel, name in enumerate(names):
            minimum = 255
            maximum = 0
            total = 0
            for y in range(height):
                for x in range(width):
                    value = int(image[y, x, channel])
                    minimum = min(minimum, value)
                    maximum = max(maximum, value)
                    total += value
            result[f"min_{name}"] = str(minimum)
            result[f"max_{name}"] = str(maximum)
            result[f"mean_{name}"] = str(total / pixels if pixels else 0.0)

    return result


def copy_manual(image: np.ndarray) -> np.ndarray:
    output = np.empty_like(image)
    if image.ndim == 2:
        for y in range(image.shape[0]):
            for x in range(image.shape[1]):
                output[y, x] = image[y, x]
    elif image.ndim == 3:
        for y in range(image.shape[0]):
            for x in range(image.shape[1]):
                for c in range(image.shape[2]):
                    output[y, x, c] = image[y, x, c]
    else:
        raise ValueError("Tipo de imagem incompatível para copia.")
    return output


def channel_image(image: np.ndarray, channel: int) -> np.ndarray:
    _require_color_bgr_uint8(image)
    output = np.zeros_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            output[y, x, channel] = image[y, x, channel]
    return output


def grayscale_average(image: np.ndarray) -> np.ndarray:
    _require_color_bgr_uint8(image)
    output = np.empty(image.shape[:2], dtype=np.uint8)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            b = int(image[y, x, 0])
            g = int(image[y, x, 1])
            r = int(image[y, x, 2])
            output[y, x] = _clamp((r + g + b) / 3.0)
    return output


def grayscale_weighted(image: np.ndarray) -> np.ndarray:
    _require_color_bgr_uint8(image)
    output = np.empty(image.shape[:2], dtype=np.uint8)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            b = int(image[y, x, 0])
            g = int(image[y, x, 1])
            r = int(image[y, x, 2])
            output[y, x] = _clamp(0.114 * b + 0.587 * g + 0.299 * r)
    return output


def quantize(image: np.ndarray, levels: int) -> np.ndarray:
    _require_grayscale_uint8(image)
    if levels not in {2, 4, 8, 16}:
        raise ValueError("levels deve ser 2, 4, 8 ou 16.")

    output = np.empty_like(image)
    max_level = levels - 1
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            pixel = int(image[y, x])
            # Quantizacao uniforme com representantes igualmente espacados em [0,255].
            index = int(pixel * max_level / 255.0 + 0.5)
            output[y, x] = int(index * 255 / max_level + 0.5)
    return output


# ---------------- M1.2 ----------------


def brightness(image: np.ndarray, value: int) -> np.ndarray:
    _require_grayscale_uint8(image)
    output = np.empty_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            pixel = int(image[y, x])
            transformed = pixel + value
            if transformed < 0:
                transformed = 0
            elif transformed > 255:
                transformed = 255
            output[y, x] = transformed
    return output


def contrast(image: np.ndarray, alpha: float) -> np.ndarray:
    _require_grayscale_uint8(image)
    output = np.empty_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            pixel = float(image[y, x])
            transformed = alpha * (pixel - 128.0) + 128.0
            output[y, x] = _clamp(transformed)
    return output


def negative(image: np.ndarray) -> np.ndarray:
    _require_grayscale_uint8(image)
    output = np.empty_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            output[y, x] = 255 - int(image[y, x])
    return output


def threshold(image: np.ndarray, threshold_value: int) -> np.ndarray:
    _require_grayscale_uint8(image)
    output = np.empty_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            output[y, x] = 0 if int(image[y, x]) < threshold_value else 255
    return output


def histogram(image: np.ndarray) -> list[int]:
    _require_grayscale_uint8(image)
    counts = [0] * 256
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            intensity = int(image[y, x])
            counts[intensity] += 1
    return counts



# ---------------- M1.3 ----------------


def _require_kernel_image(image: np.ndarray) -> None:
    _require_grayscale_uint8(image)


def _sample_pixel(image: np.ndarray, y: int, x: int, border: str) -> int:
    height, width = image.shape
    if 0 <= y < height and 0 <= x < width:
        return int(image[y, x])
    if border == "copy":
        raise IndexError("vizinhanca incompleta")
    if border == "replicate":
        yy = 0 if y < 0 else height - 1 if y >= height else y
        xx = 0 if x < 0 else width - 1 if x >= width else x
        return int(image[yy, xx])
    raise ValueError("Estrategia de borda invalida. Use copy ou replicate.")


def convolution_float(image: np.ndarray, kernel: Kernel, border: str) -> np.ndarray:
    """Convolução 2-D manual. Retorna float32 para preservar sinais e precisão."""
    _require_kernel_image(image)
    if border not in {"copy", "replicate"}:
        raise ValueError("Estrategia de borda invalida. Use copy ou replicate.")
    output = np.empty(image.shape, dtype=np.float32)
    radius = kernel.radius
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            if border == "copy" and (
                y - radius < 0 or y + radius >= image.shape[0] or
                x - radius < 0 or x + radius >= image.shape[1]
            ):
                output[y, x] = float(image[y, x])
                continue
            total = 0.0
            for ky in range(kernel.size):
                for kx in range(kernel.size):
                    # Convolução verdadeira: kernel invertido espacialmente.
                    value = _sample_pixel(
                        image,
                        y + ky - radius,
                        x + kx - radius,
                        border,
                    )
                    total += value * kernel.at(kernel.size - 1 - ky, kernel.size - 1 - kx)
            output[y, x] = total
    return output


def _to_uint8_saturated(values: np.ndarray) -> np.ndarray:
    output = np.empty(values.shape, dtype=np.uint8)
    for y in range(values.shape[0]):
        for x in range(values.shape[1]):
            value = float(values[y, x])
            if value < 0.0:
                value = 0.0
            elif value > 255.0:
                value = 255.0
            output[y, x] = int(value + 0.5)
    return output


def convolution(image: np.ndarray, kernel: Kernel, border: str) -> np.ndarray:
    return _to_uint8_saturated(convolution_float(image, kernel, border))


def _kernel_from_array(values: list[list[float]]) -> Kernel:
    size = len(values)
    return Kernel(size=size, values=tuple(float(v) for row in values for v in row))


def mean_filter(image: np.ndarray, size: int, border: str) -> np.ndarray:
    if size not in {3, 5}:
        raise ValueError("O filtro de media aceita apenas tamanho 3 ou 5.")
    weight = 1.0 / float(size * size)
    kernel = _kernel_from_array([[weight] * size for _ in range(size)])
    return convolution(image, kernel, border)


def weighted_mean(image: np.ndarray, border: str) -> np.ndarray:
    kernel = _kernel_from_array([
        [1/16, 2/16, 1/16],
        [2/16, 4/16, 2/16],
        [1/16, 2/16, 1/16],
    ])
    return convolution(image, kernel, border)


def laplacian_response(image: np.ndarray, border: str) -> np.ndarray:
    kernel = _kernel_from_array([
        [0.0, 1.0, 0.0],
        [1.0, -4.0, 1.0],
        [0.0, 1.0, 0.0],
    ])
    return convolution_float(image, kernel, border)


def laplacian(image: np.ndarray, border: str) -> np.ndarray:
    """Visualização da resposta Laplaciana: magnitude absoluta saturada."""
    response = laplacian_response(image, border)
    return _to_uint8_saturated(np.abs(response))


def laplacian_sharpen(image: np.ndarray, border: str) -> np.ndarray:
    response = laplacian_response(image, border)
    sharpened = np.empty(image.shape, dtype=np.float32)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            sharpened[y, x] = float(image[y, x]) - float(response[y, x])
    return _to_uint8_saturated(sharpened)


def sobel_components(image: np.ndarray, border: str) -> tuple[np.ndarray, np.ndarray]:
    gx_kernel = _kernel_from_array([
        [-1.0, 0.0, 1.0],
        [-2.0, 0.0, 2.0],
        [-1.0, 0.0, 1.0],
    ])
    gy_kernel = _kernel_from_array([
        [-1.0, -2.0, -1.0],
        [0.0, 0.0, 0.0],
        [1.0, 2.0, 1.0],
    ])
    return convolution_float(image, gx_kernel, border), convolution_float(image, gy_kernel, border)


def sobel_magnitudes(image: np.ndarray, border: str) -> tuple[np.ndarray, np.ndarray]:
    gx, gy = sobel_components(image, border)
    approx = np.empty(image.shape, dtype=np.float32)
    euclidean = np.empty(image.shape, dtype=np.float32)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            approx[y, x] = abs(float(gx[y, x])) + abs(float(gy[y, x]))
            euclidean[y, x] = (float(gx[y, x]) ** 2 + float(gy[y, x]) ** 2) ** 0.5
    return _to_uint8_saturated(approx), _to_uint8_saturated(euclidean)


def sobel(image: np.ndarray, border: str) -> np.ndarray:
    """Saída principal do CLI: magnitude euclidiana do Sobel, saturada em uint8."""
    _, euclidean = sobel_magnitudes(image, border)
    return euclidean

# ---------------- Dispatcher ----------------


def _print_inspection(info: dict[str, str]) -> None:
    print(f"largura: {info['width']}")
    print(f"altura: {info['height']}")
    print(f"canais: {info['channels']}")
    print(f"tipo: {info['dtype']}")
    print(f"pixels: {info['pixels']}")
    if info["channels"] == "1":
        print(f"minimo: {info['min']}")
        print(f"maximo: {info['max']}")
        print(f"media: {info['mean']}")
    else:
        for name in ("b", "g", "r"):
            print(f"minimo_{name}: {info[f'min_{name}']}")
            print(f"maximo_{name}: {info[f'max_{name}']}")
            print(f"media_{name}: {info[f'mean_{name}']}")


def run_operation(options: CliOptions) -> int:
    image = read_image(options.input)

    try:
        if options.operation == "analyze":
            if image.ndim != 2:
                raise ValueError("--input de analyze deve ser uma mascara binaria de um canal.")
            connectivity = parameter_as_int(options, "connectivity") if "connectivity" in options.parameters else 8
            min_area = parameter_as_int(options, "min_area") if "min_area" in options.parameters else 20
            kernel_size = parameter_as_int(options, "kernel_size") if "kernel_size" in options.parameters else 3
            iterations = parameter_as_int(options, "iterations") if "iterations" in options.parameters else 1
            sequence = options.parameters.get("sequence", "open-close")
            summary = analyze_mask(image, options.output, connectivity, min_area, kernel_size, iterations, sequence)
            print(f"componentes_iniciais_4: {summary['initial_components_connectivity_4']}")
            print(f"componentes_iniciais_8: {summary['initial_components_connectivity_8']}")
            print(f"componentes_finais: {summary['final']['components_raw']}")
            print(f"componentes_finais_filtrados: {summary['final']['components_filtered']}")
            print(f"pixels_primeiro_plano_inicial: {summary['initial']['foreground_pixels']}")
            print(f"pixels_primeiro_plano_final: {summary['final']['foreground_pixels']}")
            print(f"resumo: {summary['outputs']['summary']}")
            return exit_code.SUCCESS

        if options.operation == "segment":
            method = options.parameters.get("method", "fixed")
            threshold_value = parameter_as_int(options, "threshold") if "threshold" in options.parameters else 120
            mask = segment_image(image, method=method, threshold=threshold_value)
            write_image(options.output, mask)
            stats = mask_statistics(mask)
            print(f"metodo: {method}")
            print(f"dimensoes: {mask.shape[1]}x{mask.shape[0]}")
            print(f"pixels_primeiro_plano: {stats['foreground_pixels']}")
            print(f"proporcao_primeiro_plano: {stats['foreground_ratio']:.6f}")
            print("mascara_binaria: sim")
            return exit_code.SUCCESS

        if options.operation == "inspect":
            info = inspect_image(image)
            _print_inspection(info)
            if options.output:
                write_json_object(options.output, info)
            return exit_code.SUCCESS

        if options.operation == "copy":
            write_image(options.output, copy_manual(image))
            return exit_code.SUCCESS

        if options.operation == "channel_b":
            write_image(options.output, channel_image(image, 0))
            return exit_code.SUCCESS

        if options.operation == "channel_g":
            write_image(options.output, channel_image(image, 1))
            return exit_code.SUCCESS

        if options.operation == "channel_r":
            write_image(options.output, channel_image(image, 2))
            return exit_code.SUCCESS

        if options.operation == "grayscale_average":
            write_image(options.output, grayscale_average(image))
            return exit_code.SUCCESS

        if options.operation == "grayscale_weighted":
            write_image(options.output, grayscale_weighted(image))
            return exit_code.SUCCESS

        if options.operation == "quantize":
            levels = parameter_as_int(options, "levels")
            write_image(options.output, quantize(image, levels))
            return exit_code.SUCCESS

        if options.operation == "brightness":
            value = parameter_as_int(options, "value")
            write_image(options.output, brightness(image, value))
            return exit_code.SUCCESS

        if options.operation == "contrast":
            alpha = parameter_as_float(options, "alpha")
            write_image(options.output, contrast(image, alpha))
            return exit_code.SUCCESS

        if options.operation == "negative":
            write_image(options.output, negative(image))
            return exit_code.SUCCESS

        if options.operation == "threshold":
            value = parameter_as_int(options, "threshold")
            write_image(options.output, threshold(image, value))
            return exit_code.SUCCESS

        if options.operation == "histogram":
            write_histogram_csv(options.output, histogram(image))
            return exit_code.SUCCESS

        if options.operation == "convolution":
            kernel = read_kernel(parameter_as_path(options, "kernel"))
            border = parameter_as_border(options).value
            write_image(options.output, convolution(image, kernel, border))
            return exit_code.SUCCESS

        if options.operation == "mean_filter":
            size = parameter_as_int(options, "size")
            border = parameter_as_border(options).value
            write_image(options.output, mean_filter(image, size, border))
            return exit_code.SUCCESS

        if options.operation == "weighted_mean":
            border = parameter_as_border(options).value
            write_image(options.output, weighted_mean(image, border))
            return exit_code.SUCCESS

        if options.operation == "laplacian":
            border = parameter_as_border(options).value
            write_image(options.output, laplacian(image, border))
            return exit_code.SUCCESS

        if options.operation == "laplacian_sharpen":
            border = parameter_as_border(options).value
            write_image(options.output, laplacian_sharpen(image, border))
            return exit_code.SUCCESS

        if options.operation in {"sobel", "sobel_approx", "sobel_euclidean", "sobel_gx", "sobel_gy"}:
            border = parameter_as_border(options).value
            gx, gy = sobel_components(image, border)
            if options.operation == "sobel_gx":
                write_image(options.output, _to_uint8_saturated(np.abs(gx)))
            elif options.operation == "sobel_gy":
                write_image(options.output, _to_uint8_saturated(np.abs(gy)))
            else:
                approx, euclidean = sobel_magnitudes(image, border)
                write_image(options.output, approx if options.operation == "sobel_approx" else euclidean)
            return exit_code.SUCCESS

    except ValueError as error:
        print(f"Erro: {error}", file=sys.stderr)
        return exit_code.INVALID_PARAMETER

    print(
        f"Operacao '{options.operation}' reconhecida, mas ainda nao implementada no projeto-base.",
        file=sys.stderr,
    )
    return exit_code.GENERAL_ERROR
