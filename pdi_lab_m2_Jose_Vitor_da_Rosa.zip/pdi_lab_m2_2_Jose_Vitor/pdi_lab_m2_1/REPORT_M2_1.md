# Mini relatório — Laboratório M2.1: Máscara Binária e Segmentação

## 1. Alvo

O objetivo foi segmentar as maçãs presentes nas imagens, produzindo máscaras binárias para distinguir os objetos de interesse do fundo. Foram comparados dois métodos: limiarização fixa, com limiar 120, e limiarização automática de Otsu.

A segmentação foi avaliada visualmente e pela proporção de pixels classificados como primeiro plano. Como não foi utilizada uma máscara de referência anotada manualmente, os resultados não representam medidas de acurácia, precisão ou revocação.

## 2. Imagens utilizadas

Foram utilizadas duas fotografias reais:

- **Imagem favorável (`m21_favoravel1.png`):** uma maçã sobre fundo branco, com contraste visual entre o objeto e o fundo.
- **Imagem difícil (`m21_dificil1.png`):** maçãs sobre grama, com variações de iluminação e sombras, tornando a separação entre os objetos e o fundo mais complexa.

A imagem difícil foi obtida no Unsplash, em fotografia de autoria de Andriyko Podilnyk. A fonte e a licença da imagem favorável devem ser registradas conforme sua origem original.

## 3. Configurações, parâmetros e pré-processamento

Foram utilizadas as seguintes configurações:

| Configuração | Parâmetro |
|---|---|
| Método fixo | Limiar = 120 |
| Método de Otsu | Limiar calculado automaticamente |
| Conversão | Imagem colorida para tons de cinza |
| Saída | Máscara de um canal, com valores 0 e 255 |

A conversão para tons de cinza foi utilizada porque ambos os métodos trabalham com intensidade de pixel. Isso simplifica a segmentação, mas elimina parte da informação de cor que poderia ajudar a distinguir as maçãs da grama.

No método fixo, o limiar foi definido manualmente em 120. No método de Otsu, o limiar é calculado automaticamente a partir da distribuição dos níveis de cinza. Em ambos os casos, foi utilizada a binarização convencional, na qual pixels acima do limiar são classificados como primeiro plano.

## 4. Resultados quantitativos

A tabela apresenta a quantidade e a proporção de pixels classificados como primeiro plano em cada configuração.

| Imagem | Configuração | Pixels de primeiro plano | Proporção |
|---|---|---:|---:|
| Favorável | Fixo (120) | 2.348.392 | 83,94% |
| Favorável | Otsu | 2.337.135 | 83,54% |
| Difícil | Fixo (120) | 1.090.539 | 36,40% |
| Difícil | Otsu | 1.201.613 | 40,10% |

A comparação direta das máscaras identificou 11.257 pixels diferentes na imagem favorável (0,40%) e 111.074 na imagem difícil (3,71%). Esses valores medem a diferença entre as máscaras produzidas pelos métodos, e não a qualidade absoluta da segmentação.

## 5. Figuras e observações visuais

Inserir nesta seção as sobreposições geradas em `images/output`. As regiões avermelhadas representam os pixels classificados como primeiro plano.

**Figura 1 — Imagem favorável segmentada pelo método fixo.**  
Arquivo: `images/output/m21_favoravel1_fixed_overlay.png`. A maçã aparece destacada em vermelho, mas o fundo branco apresenta tonalidade rosada, indicando seleção indesejada de parte do fundo.

**Figura 2 — Imagem favorável segmentada pelo método de Otsu.**  
Arquivo: `images/output/m21_favoravel1_otsu_overlay.png`. O comportamento visual é semelhante ao do método fixo: a maçã fica destacada, mas parte do fundo também é classificada como primeiro plano.

**Figura 3 — Imagem difícil segmentada pelo método fixo.**  
Arquivo: `images/output/m21_dificil1_fixed_overlay.png`. As maçãs aparecem em vermelho claro e a grama permanece predominantemente verde. Entretanto, existe uma grande mancha vermelha na parte superior da imagem, correspondente à seleção indesejada de uma região do fundo.

**Figura 4 — Imagem difícil segmentada pelo método de Otsu.**  
Arquivo: `images/output/m21_dificil1_otsu_overlay.png`. As maçãs também aparecem destacadas e a grama permanece predominantemente verde, mas a mancha vermelha na parte superior continua presente.

## 6. Discussão comparativa

### (a) Em que casos o limiar fixo falhou ou funcionou?

Na imagem favorável, o limiar fixo destacou a maçã, mas também classificou parte do fundo branco como primeiro plano. Portanto, funcionou parcialmente: o objeto ficou visível na máscara, porém não foi isolado completamente.

Na imagem difícil, o método destacou as maçãs e manteve a maior parte da grama fora da região selecionada. Contudo, a mancha vermelha na parte superior indica falsos positivos. Assim, o método funcionou para destacar os objetos, mas falhou em eliminar todas as regiões indesejadas do fundo.

### (b) Qual parâmetro foi mais sensível?

O parâmetro de limiarização foi relevante para os resultados: no método fixo, o valor 120 determina diretamente quais intensidades serão selecionadas; no método de Otsu, o limiar é calculado automaticamente.

Na imagem favorável, as máscaras diferiram em apenas 0,40% dos pixels, enquanto na imagem difícil diferiram em 3,71%. Isso indica que a escolha do limiar teve maior efeito na imagem difícil. Entretanto, não foi realizado um experimento variando sistematicamente diferentes valores do limiar fixo. Portanto, não é possível afirmar qual parâmetro é globalmente o mais sensível; os resultados mostram apenas que as máscaras foram mais diferentes na imagem difícil.

### (c) Quais erros podem atrapalhar a contagem de objetos no M2.2?

Os principais problemas observados ou possíveis são:

- **Falsos positivos:** regiões do fundo classificadas como primeiro plano, como a mancha vermelha na parte superior da imagem difícil.
- **Falsos negativos:** partes de uma maçã classificadas como fundo, caso existam regiões que não ultrapassem o limiar.
- **Fragmentação:** uma maçã pode aparecer dividida em várias regiões desconectadas.
- **Fusão de objetos:** maçãs próximas podem ficar conectadas na máscara e ser interpretadas como um único objeto.
- **Ruído:** pequenas regiões selecionadas fora das maçãs podem ser interpretadas como objetos adicionais.

Esses problemas podem levar a contagens maiores ou menores que o número real de maçãs. Por isso, a qualidade da máscara binária é importante para as etapas de análise de componentes conectados e contagem de objetos no M2.2.

## 7. Conclusão

Os dois métodos produziram máscaras binárias válidas e destacaram visualmente as maçãs nas duas fotografias. Na imagem favorável, os resultados foram muito semelhantes, com diferença de 0,40% dos pixels. Na imagem difícil, a diferença foi de 3,71%, mas ambos os métodos apresentaram uma região indesejada selecionada na parte superior.

A avaliação mostra que a limiarização por intensidade de cinza é útil para uma segmentação inicial, mas pode incluir partes do fundo quando suas intensidades são semelhantes às dos objetos. A inspeção visual complementa os resultados quantitativos, pois a proporção de primeiro plano e a diferença entre máscaras não indicam, por si sós, se a segmentação está correta.

## 8. Referências

OpenCV. *Image Thresholding*. Documentação oficial. Disponível em: https://docs.opencv.org/4.x/d7/d4d/tutorial_py_thresholding.html. Acesso em: 20 out. 2026.
