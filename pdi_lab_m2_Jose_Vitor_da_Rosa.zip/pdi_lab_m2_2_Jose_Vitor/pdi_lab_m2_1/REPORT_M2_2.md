# Relatório --- Processamento de Imagens

## Laboratório M2.2 --- Componentes conexos e sequência morfológica

### 1. Identificação

-   **Estudante:** José Vitor da Rosa
-   **Disciplina:** Processamento de Imagens
-   **Laboratório:** M2.2 --- Componentes conexos e sequência
    morfológica
-   **Data:** 20/10/2026


### 2. Objetivo

Ampliar o processamento desenvolvido no M2.1 para analisar máscaras
binárias, identificar componentes conexos, comparar conectividades 4 e
8, aplicar uma sequência morfológica de abertura seguida de fechamento e
filtrar componentes por área mínima. Foram analisadas duas imagens reais
--- favorável e difícil --- e duas imagens sintéticas com os mesmos
nomes de caso.

### 3. Metodologia

As imagens foram processadas pelo projeto Python/OpenCV do laboratório.
Nas imagens originais, foi executada a operação de segmentação do M2.1
com limiar fixo de 120, gerando máscaras binárias. Em seguida, as
máscaras foram analisadas pelo M2.2.

Parâmetros usados na análise: - Conectividade selecionada: 8. -
Conectividade comparativa: 4 e 8. - Sequência morfológica: `open-close`
(abertura seguida de fechamento). - Elemento estruturante: retangular,
(3 `\times 3`{=tex}). - Iterações por etapa: 1. - Área mínima para
manter um componente: 100 pixels.

A abertura tende a remover pequenas regiões de primeiro plano e detalhes
finos; o fechamento tende a preencher pequenas lacunas e aproximar
regiões. Os efeitos dependem da forma e da escala dos objetos da
máscara. O filtro de área elimina componentes com área inferior a 100
pixels.

### 4. Resultados quantitativos

#### 4.1 Comparação das quatro imagens

  -------------------------------------------------------------------------------------------
  Caso          Componentes   Componentes   Componentes   Componentes   Pixels de   Pixels de
               iniciais (4)  iniciais (8)          após      mantidos    primeiro    primeiro
                                             morfologia   (área ≥ 100       plano plano final
                                                                  px)     inicial 
  ----------- ------------- ------------- ------------- ------------- ----------- -----------
  Real                  558           481            24             3   2.348.392   2.346.100
  favorável                                                                       

  Real                1.517         1.078           239            81   1.090.539   1.080.394
  difícil                                                                         

  Sintética               3             3             3             3      11.823      11.823
  favorável                                                                       

  Sintética           1.048           510            24             3      31.457      27.118
  difícil                                                                         
  -------------------------------------------------------------------------------------------

**Nota:** "componentes após morfologia" representa a contagem depois da
sequência `open-close`, antes do filtro por área. "Componentes mantidos"
corresponde à contagem após aplicar a área mínima de 100 pixels. Os
valores foram transcritos das saídas do terminal fornecidas durante a
execução.

#### 4.2 Alteração dos pixels de primeiro plano

  Caso                    Variação de pixels   Variação percentual aproximada
  --------------------- -------------------- --------------------------------
  Real favorável                      −2.292                           −0,10%
  Real difícil                       −10.145                           −0,93%
  Sintética favorável                      0                            0,00%
  Sintética difícil                   −4.339                          −13,79%

A variação percentual é calculada em relação à quantidade inicial de
pixels de primeiro plano. Uma redução de pixels não significa, por si
só, que o resultado melhorou: é necessário verificar se o processamento
removeu ruído ou também eliminou partes relevantes dos objetos.

### 5. Análise individual

#### 5.1 Imagem real favorável

A máscara inicial apresentou 558 componentes com conectividade 4 e 481
com conectividade 8. A diferença indica que parte das regiões
consideradas separadas na conectividade 4 se conecta diagonalmente
quando se utiliza conectividade 8. Após a sequência morfológica, a
contagem caiu para 24 componentes; com a área mínima de 100 pixels,
permaneceram 3. A quantidade de pixels de primeiro plano passou de
2.348.392 para 2.346.100, redução de 2.292 pixels (aproximadamente
0,10%).

A pequena alteração na quantidade de pixels, acompanhada da redução no
número de componentes, sugere que a morfologia modificou principalmente
regiões pequenas, conexões ou fragmentos sem alterar substancialmente a
área total do primeiro plano. A inspeção das imagens inicial e final
deve confirmar se os três componentes mantidos correspondem às regiões
de interesse.

#### 5.2 Imagem real difícil

A máscara inicial apresentou 1.517 componentes com conectividade 4 e
1.078 com conectividade 8. Após a morfologia, restaram 239 componentes
e, depois do filtro de área, 81. Os pixels de primeiro plano diminuíram
de 1.090.539 para 1.080.394, uma redução de 10.145 pixels
(aproximadamente 0,93%).

A quantidade maior de componentes que sobreviveu ao filtro, em
comparação com a imagem real favorável, mostra que a máscara difícil
continua mais fragmentada ou contém mais regiões suficientemente grandes
para ultrapassar o limite de área. A sequência reduziu o número de
componentes, mas não eliminou toda a fragmentação. Deve-se conferir
visualmente se os componentes removidos eram ruído ou partes legítimas
dos objetos.

#### 5.3 Imagem sintética favorável


A imagem apresentou 3 componentes tanto na conectividade 4 quanto na
conectividade 8. A sequência morfológica manteve 3 componentes e a
quantidade de pixels de primeiro plano permaneceu em 11.823. O filtro de
área manteve os 3 componentes.

Esse resultado é compatível com uma máscara simples, cujas regiões não
se conectam apenas por diagonais e não são significativamente alteradas
pelo elemento estruturante utilizado. A confirmação final depende de
comparar a máscara e a imagem rotulada com o número de objetos que foram
desenhados na sintética.

#### 5.4 Imagem sintética difícil

A conectividade 4 identificou 1.048 componentes, enquanto a
conectividade 8 identificou 510. Essa diferença expressiva indica que
muitas regiões se relacionam por contatos diagonais. Depois da sequência
morfológica, restaram 24 componentes; com a área mínima de 100 pixels,
apenas 3 foram mantidos. Os pixels de primeiro plano diminuíram de
31.457 para 27.118, redução de 4.339 pixels (aproximadamente 13,79%).

A redução mais expressiva em comparação com as outras três imagens
mostra que a sequência morfológica alterou consideravelmente esta
máscara. O resultado pode representar a remoção de ruído e a correção de
pequenos detalhes, mas também pode indicar perda de partes válidas. Por
isso, é especialmente importante inspecionar
`m22_sintetica_dificil_final.png` e `m22_sintetica_dificil_labels.png`
antes de afirmar que os três componentes finais são os objetos
esperados.

### 6. Discussão comparativa

Os resultados evidenciam que a conectividade escolhida altera a
interpretação de regiões diagonais. Em todos os casos em que as
contagens diferem, a conectividade 8 identifica menos componentes do que
a conectividade 4, pois considera conexões diagonais.

A sequência `open-close` teve efeito distinto conforme a máscara de
entrada. A sintética favorável não sofreu alteração mensurável na área
do primeiro plano, enquanto a sintética difícil perdeu aproximadamente
13,79% dos pixels de primeiro plano. Nas imagens reais, a redução foi
menor que 1%. Isso reforça que parâmetros iguais não produzem efeitos
iguais em imagens diferentes.

O limite de 100 pixels também é relevante: ele remove componentes
pequenos mesmo quando estes ainda existem depois da morfologia.
Portanto, a contagem após o filtro não deve ser confundida com a
contagem de componentes imediatamente após `open-close`. A validação
visual é necessária para distinguir remoção de ruído de perda de
objetos.

### 7. Conclusão

O laboratório aplicou análise de componentes conexos e sequência
morfológica a duas máscaras derivadas de imagens reais e duas imagens
sintéticas. Os resultados mostram diferenças entre conectividade 4 e 8 e
demonstram que a abertura seguida de fechamento afeta cada máscara de
maneira distinta. A sintética favorável permaneceu estável; a sintética
difícil foi bastante alterada; e as imagens reais apresentaram reduções
menores na área de primeiro plano, embora com redução no número de
componentes.

A principal limitação da avaliação numérica é que uma redução no número
de componentes ou na área de primeiro plano não comprova, isoladamente,
melhor segmentação. A análise deve ser complementada pela inspeção das
máscaras inicial e final e das imagens de rótulos, verificando se os
objetos de interesse foram preservados.

### 8. Arquivos de resultados a incluir

Os arquivos de saída estão na pasta `results/`. Incluir ou consultar,
para cada caso:

-   Máscara inicial do M2.1 (`*_mask.png`).
-   Máscara inicial analisada (`*_initial.png`).
-   Resultado final após morfologia (`*_final.png`).
-   Imagem de componentes rotulados (`*_labels.png`).
-   Arquivos CSV e resumo JSON correspondentes (`*_initial.csv`,
    `*_final.csv`, `*_summary.json`).

Arquivos específicos dos casos sintéticos: -
`results/m21_sintetica_favoravel_mask.png` -
`results/m21_sintetica_dificil_mask.png` -
`results/m22_sintetica_favoravel_initial.png` -
`results/m22_sintetica_favoravel_final.png` -
`results/m22_sintetica_favoravel_labels.png` -
`results/m22_sintetica_favoravel_summary.json` -
`results/m22_sintetica_dificil_initial.png` -
`results/m22_sintetica_dificil_final.png` -
`results/m22_sintetica_dificil_labels.png` -
`results/m22_sintetica_dificil_summary.json`

### 9. Referências

OPENCV. **Image Thresholding**. OpenCV Documentation. Disponível em:
https://docs.opencv.org/4.x/d7/d4d/tutorial_py_thresholding.html. Acesso
em: 20 out. 2026.

OPENCV. **Connected Components and Statistics**. OpenCV Documentation.
Disponível em:
https://docs.opencv.org/4.x/d3/dc0/group\_\_imgproc\_\_shape.html.
Acesso em: 20 out. 2026.

OPENCV. **More Morphology Transformations**. OpenCV Documentation.
Disponível em:
https://docs.opencv.org/4.x/d3/dbe/tutorial_opening_closing_hats.html.
Acesso em: 20 out. 2026.

OTSU, Nobuyuki. A threshold selection method from gray-level histograms.
**IEEE Transactions on Systems, Man, and Cybernetics**, v. 9, n. 1,
p. 62--66, 1979. DOI: https://doi.org/10.1109/TSMC.1979.4310076.

GONZALEZ, Rafael C.; WOODS, Richard E. **Digital Image Processing**. 4.
ed. New York: Pearson, 2018.

------------------------------------------------------------------------


